<?php

namespace App\Http\Controllers;

use App\Models\Lead;
use App\Models\Distribuidore;
use App\Models\Cerrador;
use App\Models\Nota;
use App\Models\statuses;
use App\Models\User;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Spatie\Permission\Models\Role;
use Illuminate\Support\Facades\Validator;

/**
 * Class LeadController
 * @package App\Http\Controllers
 */
class LeadController extends Controller
{
        /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response 
     */

         public function index(Request $request){
                         //me trae usarios con el rol ventas mediante el query
            $usuariosConRol = User::whereHas("roles", function($q){ $q->where("name", "Ventas"); })->get();
             $username = auth()->user()->name;
            $userrole = auth()->user()->roles()->first()->name;
            if($userrole=='Administrador'){
                $fecha1= $request->get('fecha1');
                 $fecha2= $request->get('fecha2');
                 
        
                  $nombre= $request->get('busqueda');    
        
                 $leads = lead::nombres($nombre)->fechas($fecha1,$fecha2)->orderBy('created_at', 'desc')->Paginate(15);
                 
                
                 
                 return view('lead.indexAdmin', compact('leads','usuariosConRol'))
                 ->with('i', (request()->input('page', 1) - 1) * $leads->perPage());

            }else{
                $fecha1= $request->get('fecha1');
                 $fecha2= $request->get('fecha2');

        
                 $nombre= $request->get('busqueda');    
        
                 
                 //$leads = lead::nombres($nombre)->fechas($fecha1,$fecha2)->paginate(15);
                 $leads = lead::with('User')->where('user_id', auth()->user()->id)->nombres($nombre)->fechas($fecha1,$fecha2)->orderBy('created_at', 'desc')->paginate(15);
                 ;
                  return view('lead.indexDist', compact('leads','usuariosConRol'))
                  ->with('i', (request()->input('page', 1) - 1) * $leads->perPage());

            }


    }
    public function asignar(Request $request){
            
          
         
           
 
            //me trae usarios con el rol ventas mediando el query
            $usuariosConRol = User::whereHas("roles", function($q){ $q->where("name", "Ventas"); })->get();
           // este me trae todos los usuarios que tienen roles
          // $usuariosConRol = User::has('roles')->get();
          
          
            $status = statuses::all();
            $distribuidores = User::whereHas("roles", function($q){ $q->where("name", "Distribuidor")->orWhere('name', '=', 'Administrador')->orWhere('name', '=', 'Gerente'); })->get();
            $cerradores = Cerrador::all();
            $username = auth()->user()->name;
            $userrole = auth()->user()->roles()->first()->name;
           
            $fecha1= $request->get('fecha1');
            $fecha2= $request->get('fecha2');
                
            $statusb = $request->get('status');
            $userid = $request->get('userid');
            $matricula= $request->get('matriculaid');    
            if($statusb && $matricula){
                $leads = lead::where('statuses_id', $statusb)->users($matricula)->whereNull('id_vendedor')->Paginate(15);

            }elseif($statusb == "" && $matricula == ""){
                 $leads = lead::whereNull('id_vendedor')->Paginate(15);
                   
            }elseif($matricula){
                $leads = lead::users($matricula)->whereNull('id_vendedor')->Paginate(15);
                
            }else{
                 $leads = lead::where('statuses_id', $statusb)->whereNull('id_vendedor')->Paginate(15); 
            }
                 
                               

                 return view('lead.asignar', compact('leads','distribuidores','status','usuariosConRol'))->with('i', (request()->input('page', 1) - 1) * $leads->perPage());
                 

            


    }
     protected function validator(array $data)
    {

         return Validator::make($data, [
            'Uventas' => ['required'],
            'nlead' => ['required'],
            'statusb' => ['required'],
            'matricula'  =>['required'],
            
             ]);
        
        
    }

       /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  Lead $lead
     * @param  Nota $nota
     * @return \Illuminate\Http\Response
     */
    public function updateAsignar(Request $request ){
         

        //usario al que se le asigan
        $Uventas = $request->get('Uventas');
        //numeros de leads a asignar
        $nlead = $request->get('nlead');
        //si se asigaran por estado o general
        $statusb = $request->get('statusb');
        //matricula de dsitribuidor
        $matricula= $request->get('matriculaid');
        
       if($statusb && $matricula && $nlead){
            $leads = lead::latest()->take($nlead)->users($matricula)->where('statuses_id', $statusb)->whereNull('id_vendedor')->get();
                    $leads->toQuery()->update(['id_vendedor' => $Uventas]);
                     return redirect()->route('asignar')
                     ->with('success', 'Lead asignados correctamente successfully');
       }else{
           return redirect()->route('asignar')
                     ->with('danger', 'la informacion es requerida completa');
       }
       
        
       



    }
    
    
    
    
     public function reasignar(Request $request){
            
          
         
           
 
            //me trae usarios con el rol ventas mediante el query
            $usuariosConRol = User::whereHas("roles", function($q){ $q->where("name", "Ventas"); })->get();
           
         
           // este me trae todos los usuarios que tienen roles
          // $usuariosConRol = User::has('roles')->get();
          
            $status = statuses::all();
            $distribuidores = Distribuidore::all();
            $cerradores = Cerrador::all();
            $username = auth()->user()->name;
            $userrole = auth()->user()->roles()->first()->name;
           
            $fecha1= $request->get('fecha1');
            $fecha2= $request->get('fecha2');
            $vendedor= $request->get('vendedor');    
            $statusb = $request->get('status');
            $userid = $request->get('userid');
            $matricula= $request->get('matriculaid');    
            if($vendedor && $statusb == "" && $matricula == ""){
                $leads = lead::where('id_vendedor',$vendedor)->Paginate(15); 
                
            }elseif($vendedor == "" && $statusb  && $matricula == ""){
                $leads = lead::where('statuses_id', $statusb)->whereNotNull('id_vendedor')->Paginate(15);
            }
            elseif($vendedor  && $statusb  && $matricula == ""){
                $leads = lead::where('id_vendedor',$vendedor)->where('statuses_id', $statusb)->Paginate(15);
            }
            elseif($vendedor  && $statusb == ""  && $matricula ){
                $leads = lead::where('id_vendedor',$vendedor)->users($matricula)->Paginate(15);
            }
            elseif($vendedor && $statusb && $matricula){
                $leads = lead::where('id_vendedor',$vendedor)->users($matricula)->where('statuses_id', $statusb)->Paginate(15);
            }
            elseif($statusb == "" && $matricula == "" && $vendedor == ""){
                 $leads = lead::whereNotNull('id_vendedor')->Paginate(15);
                   
            }else{
                 $leads = lead::where('id_vendedor',$vendedor)->Paginate(15); 
            }
                
                               

                 return view('lead.reasignar', compact('leads','distribuidores','status','usuariosConRol','vendedor'))->with('i', (request()->input('page', 1) - 1) * $leads->perPage());
                 

            


    }
           /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  Lead $lead
     * @param  Nota $nota
     * @return \Illuminate\Http\Response
     */
    public function updateReasignar(Request $request ){

        $Uventas2 = $request->get('Uventas2');
        //usario al que se le asigan
        $Uventas = $request->get('Uventas');
        //numeros de leads a asignar
        $nlead = $request->get('nlead');
        //si se asigaran por estado o general
        $statusb = $request->get('statusb');
        //matricula de dsitribuidor
        $matricula= $request->get('matriculaid');
        
       if($statusb && $matricula && $nlead && $Uventas2){
           
            $leads = lead::latest()->take($nlead)->users($matricula)->where('statuses_id', $statusb)->where('id_vendedor',$Uventas2)->get();
            
                    $leads->toQuery()->update(['id_vendedor' => $Uventas]);
                     return redirect()->route('reasignar')
                     ->with('success', 'Lead asignados correctamente successfully');
       }else{
           return redirect()->route('reasignar')
                     ->with('danger', 'la informacion es requerida completa');
       }
       
        
       



    }
    
    
     public function nuevo(Request $request){
             $username = auth()->user()->name;
             
             $userid = auth()->user()->id;
            $userrole = auth()->user()->roles()->first()->name;
            if($userrole=='Administrador'){
                $fecha1= $request->get('fecha1');
                 $fecha2= $request->get('fecha2');
                 
        
                  $nombre= $request->get('busqueda');    
        
                 $leads = lead::nombres($nombre)->fechas($fecha1,$fecha2)->Paginate(15);

                 return view('lead.indexAdmin', compact('leads'))
                 ->with('i', (request()->input('page', 1) - 1) * $leads->perPage());

            }else{
                $fecha1= $request->get('fecha1');
                 $fecha2= $request->get('fecha2');

        
                 $nombre= $request->get('busqueda');    
        
                 
                 //$leads = lead::nombres($nombre)->fechas($fecha1,$fecha2)->paginate(15);
                 $leads = lead::where('statuses_id', '1')->where('id_vendedor',$userid)->nombres($nombre)->fechas($fecha1,$fecha2)->paginate(15);
                  return view('lead.ventas', compact('leads'))
                  ->with('i', (request()->input('page', 1) - 1) * $leads->perPage());

            }


    }
 public function seguimiento(Request $request){
             $username = auth()->user()->name;
             $userid = auth()->user()->id;
            $userrole = auth()->user()->roles()->first()->name;
            if($userrole=='Administrador'){
                $fecha1= $request->get('fecha1');
                 $fecha2= $request->get('fecha2');
                 
        
                  $nombre= $request->get('busqueda');    
        
                 $leads = lead::nombres($nombre)->fechas($fecha1,$fecha2)->Paginate(15);

                 return view('lead.indexAdmin', compact('leads'))
                 ->with('i', (request()->input('page', 1) - 1) * $leads->perPage());

            }else{
                $fecha1= $request->get('fecha1');
                 $fecha2= $request->get('fecha2');

        
                 $nombre= $request->get('busqueda');    
        
                 
                 //$leads = lead::nombres($nombre)->fechas($fecha1,$fecha2)->paginate(15);
                 $leads = lead::with('statuses')->where('statuses_id', '2')->where('id_vendedor',$userid)->nombres($nombre)->fechas($fecha1,$fecha2)->paginate(15);
                  return view('lead.ventas', compact('leads'))
                  ->with('i', (request()->input('page', 1) - 1) * $leads->perPage());

            }


    }
     public function nocontesto(Request $request){
             $username = auth()->user()->name;
             $userid = auth()->user()->id;
            $userrole = auth()->user()->roles()->first()->name;
            if($userrole=='Administrador'){
                $fecha1= $request->get('fecha1');
                 $fecha2= $request->get('fecha2');
                 
        
                  $nombre= $request->get('busqueda');    
        
                 $leads = lead::nombres($nombre)->fechas($fecha1,$fecha2)->Paginate(15);

                 return view('lead.indexAdmin', compact('leads'))
                 ->with('i', (request()->input('page', 1) - 1) * $leads->perPage());

            }else{
                $fecha1= $request->get('fecha1');
                 $fecha2= $request->get('fecha2');

        
                 $nombre= $request->get('busqueda');    
        
                 
                 //$leads = lead::nombres($nombre)->fechas($fecha1,$fecha2)->paginate(15);
                 $leads = lead::with('statuses')->where('statuses_id', '3')->where('id_vendedor',$userid)->nombres($nombre)->fechas($fecha1,$fecha2)->paginate(15);
                  return view('lead.ventas', compact('leads'))
                  ->with('i', (request()->input('page', 1) - 1) * $leads->perPage());

            }


    }
    public function nointeresado(Request $request){
             $username = auth()->user()->name;
             $userid = auth()->user()->id;
            $userrole = auth()->user()->roles()->first()->name;
            if($userrole=='Administrador'){
                $fecha1= $request->get('fecha1');
                 $fecha2= $request->get('fecha2');
                 
        
                  $nombre= $request->get('busqueda');    
        
                 $leads = lead::nombres($nombre)->fechas($fecha1,$fecha2)->Paginate(15);

                 return view('lead.indexAdmin', compact('leads'))
                 ->with('i', (request()->input('page', 1) - 1) * $leads->perPage());

            }else{
                $fecha1= $request->get('fecha1');
                 $fecha2= $request->get('fecha2');

        
                 $nombre= $request->get('busqueda');    
        
                 
                 //$leads = lead::nombres($nombre)->fechas($fecha1,$fecha2)->paginate(15);
                 $leads = lead::with('statuses')->where('statuses_id', '4')->where('id_vendedor',$userid)->nombres($nombre)->fechas($fecha1,$fecha2)->paginate(15);
                  return view('lead.ventas', compact('leads'))
                  ->with('i', (request()->input('page', 1) - 1) * $leads->perPage());

            }


    }
    public function activados(Request $request){
             $username = auth()->user()->name;
             $userid = auth()->user()->id;
            $userrole = auth()->user()->roles()->first()->name;
            if($userrole=='Administrador'){
                $fecha1= $request->get('fecha1');
                 $fecha2= $request->get('fecha2');
                 
        
                  $nombre= $request->get('busqueda');    
        
                 $leads = lead::nombres($nombre)->fechas($fecha1,$fecha2)->Paginate(15);

                 return view('lead.indexAdmin', compact('leads'))
                 ->with('i', (request()->input('page', 1) - 1) * $leads->perPage());

            }else{
                $fecha1= $request->get('fecha1');
                 $fecha2= $request->get('fecha2');

        
                 $nombre= $request->get('busqueda');    
        
                 
                 //$leads = lead::nombres($nombre)->fechas($fecha1,$fecha2)->paginate(15);
                 $leads = lead::with('statuses')->where('statuses_id', '5')->where('id_vendedor',$userid)->nombres($nombre)->fechas($fecha1,$fecha2)->paginate(15);
                  return view('lead.ventas', compact('leads'))
                  ->with('i', (request()->input('page', 1) - 1) * $leads->perPage());

            }


    }
     public function datosincorrectos(Request $request){
             $username = auth()->user()->name;
             $userid = auth()->user()->id;
            $userrole = auth()->user()->roles()->first()->name;
            if($userrole=='Administrador'){
                $fecha1= $request->get('fecha1');
                 $fecha2= $request->get('fecha2');
                 
        
                  $nombre= $request->get('busqueda');    
        
                 $leads = lead::nombres($nombre)->fechas($fecha1,$fecha2)->Paginate(15);

                 return view('lead.indexAdmin', compact('leads'))
                 ->with('i', (request()->input('page', 1) - 1) * $leads->perPage());

            }else{
                $fecha1= $request->get('fecha1');
                 $fecha2= $request->get('fecha2');

        
                 $nombre= $request->get('busqueda');    
        
                 
                 //$leads = lead::nombres($nombre)->fechas($fecha1,$fecha2)->paginate(15);
                 $leads = lead::with('statuses')->where('statuses_id', '6')->where('id_vendedor',$userid)->nombres($nombre)->fechas($fecha1,$fecha2)->paginate(15);
                  return view('lead.ventas', compact('leads'))
                  ->with('i', (request()->input('page', 1) - 1) * $leads->perPage());

            }


    }
    public function preregistro(Request $request){
             $username = auth()->user()->name;
             $userid = auth()->user()->id;
            $userrole = auth()->user()->roles()->first()->name;
            if($userrole=='Administrador'){
                $fecha1= $request->get('fecha1');
                 $fecha2= $request->get('fecha2');
                 
        
                  $nombre= $request->get('busqueda');    
        
                 $leads = lead::nombres($nombre)->fechas($fecha1,$fecha2)->Paginate(15);

                 return view('lead.indexAdmin', compact('leads'))
                 ->with('i', (request()->input('page', 1) - 1) * $leads->perPage());

            }else{
                $fecha1= $request->get('fecha1');
                 $fecha2= $request->get('fecha2');

        
                 $nombre= $request->get('busqueda');    
        
                 
                 //$leads = lead::nombres($nombre)->fechas($fecha1,$fecha2)->paginate(15);
                 $leads = lead::with('statuses')->where('statuses_id', '7')->where('id_vendedor',$userid)->nombres($nombre)->fechas($fecha1,$fecha2)->paginate(15);
                  return view('lead.ventas', compact('leads'))
                  ->with('i', (request()->input('page', 1) - 1) * $leads->perPage());

            }


    }
        public function index2()
    {
      

        return view('livewire.index');
            
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $date = Carbon::now();
        $lead = new lead();
        $userrole = auth()->user()->roles()->first()->name;
        $username2 = auth()->user()->name;
        $username = auth()->user()->id;
            return view('lead.create', compact('lead',"username",'username2','date'));

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(Lead::$rules);
//aqui se creara la nota
        $lead = Lead::create($request->all()); 
        $username = auth()->user()->name;
        $userrole = auth()->user()->roles()->first()->name;
        if ($userrole=='Administrador') {
             return redirect()->route('indexAdmin')
            ->with('success', 'Lead creado correctamente.');
                   // code...
        }else{
             return redirect()->route('indexDist')
            ->with('success', 'Lead creado correctamente.');
                   // code...
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id, Request $request, Nota $nota)
    {
        $lead = Lead::find($id);
        $user = lead::find($id)->User;
        $notas = lead::find($id)->Nota;
        $cerradors = lead::find($id)->Cerrador;
        $statuses = lead::find($id)->statuses;
        $nota->leads_id = $id;
        $username2 = auth()->user()->name;
        $status = statuses::all();
        $cerradores = Cerrador::all();
        $date = $lead->created_at2;
        

       return view('lead.show', compact('cerradores','status','lead','notas','nota','username2','user','cerradors','statuses'));
    }
        /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
  /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  Lead $lead
     * @param  Nota $nota
     * @return \Illuminate\Http\Response
     */
    public function showStore(Request $request, $id, Nota $nota, Lead $lead)
    {
        
        
       $user = lead::find($id)->User;
       $notas = lead::find($id)->Nota;
       $username2 = auth()->user()->name;
       $lead = Lead::find($id);
       $date = $lead->created_at2;
        if($request->nota == null){
            
            $lead->update($request->all());
        }else{
        
        $nota = Nota::create($request->all()); 
        }

       
        
        
        return redirect()->route('lead.show',$id)
            ->with('success', 'Nota creado correctamente.');
       // return view('lead.show', compact('nota','lead','username2','notas'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $lead = Lead::find($id);
        $date = $lead->created_at2;
         $userrole = auth()->user()->roles()->first()->name;
        $username2 = auth()->user()->name;
        $username = auth()->user()->id;
        if($userrole == 'Distribuidor'){
            $lead = Lead::find($id);
            $username = auth()->user()->id;
            $username2 = auth()->user()->name;
        }else{
        $lead = Lead::find($id);
        $nota = new Nota();
        $nota->leads_id = $id;
        
        $username2 = auth()->user()->name;
        $username = auth()->user()->id;
        }

        return view('lead.edit', compact('lead','username','nota','username2','date'));
    }
        public function editWorksheet($id)
    {
        $lead = Lead::find($id);
        $date = $lead->created_at2;
         $userrole = auth()->user()->roles()->first()->name;
        $username2 = auth()->user()->name;
        $username = auth()->user()->id;
        if($userrole == 'Distribuidor'){
            $lead = Lead::find($id);
            $username = auth()->user()->id;
            $username2 = auth()->user()->name;
        }else{
        $lead = Lead::find($id);
        $nota = new Nota();
        $nota->leads_id = $id;
        
        $username2 = auth()->user()->name;
        $username = auth()->user()->id;
        }

        return view('lead.worksheet-q', compact('lead','username','nota','username2','date'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  Lead $lead
     * @param  Nota $nota
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Lead $lead, Nota $nota){
        
    
        request()->validate(Lead::$rules);
        
      

        
        $userrole = auth()->user()->roles()->first()->name;
        $username = auth()->user()->id;
        if($request->nota == null or $userrole == "Distribuidor"){
        $lead->update($request->all());
        }else{
        $lead->update($request->all());
        $nota = Nota::create($request->all());
            echo "nota es actualizacion completa ";
        }
        return redirect()->route('indexAdmin')
            ->with('success', 'Lead actualizado successfully');
    }
        /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  Lead $lead
     * @param  Nota $nota
     * @return \Illuminate\Http\Response
     */
    public function showUpdate(Request $request, Lead $lead, $id){
        
       $lead = Lead::find($id);
       $statusBD = Lead::find($id)->statuses;

        $lead->cerrador_id = $request->input('cerrador_id');
        $lead->statuses_id = $request->input('statuses_id');
       
         $lead->update();
         
         if($request->input('cerrador_id')){
        return redirect()->route('lead.show',$id)
            ->with('success', 'Lead actualizado successfully');
        }elseif($request->input('statuses_id')== 5){
             return redirect()->route('editWorksheet',$lead->id)
            ->with('success', 'Lead status actualizado successfully');
        }else{
            return redirect()->route('lead.show',$id)
            ->with('success', 'Lead actualizado successfully'); 
        } 
       
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $lead = Lead::find($id)->delete();

        return redirect()->route('lead.index')
            ->with('success', 'Lead deleted successfully');
    }
}
