<h3>Editar Distribuidor</h3>

    @include('livewire.form')

<button class="btn btn-primary" wire:click="update">Guardar cambios</button>