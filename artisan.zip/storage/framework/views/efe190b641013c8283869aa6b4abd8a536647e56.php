<?php $__env->startSection('template_title'); ?>
    <?php echo e($distribuidore->name ?? 'Show Distribuidore'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Distribuidore</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="<?php echo e(route('distribuidores.index')); ?>"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Razonsocial:</strong>
                            <?php echo e($distribuidore->razonsocial); ?>

                        </div>
                        <div class="form-group">
                            <strong>Representantelegal:</strong>
                            <?php echo e($distribuidore->representantelegal); ?>

                        </div>
                        <div class="form-group">
                            <strong>Rfc:</strong>
                            <?php echo e($distribuidore->rfc); ?>

                        </div>
                        <div class="form-group">
                            <strong>Direccion:</strong>
                            <?php echo e($distribuidore->direccion); ?>

                        </div>
                        <div class="form-group">
                            <strong>Ciudad:</strong>
                            <?php echo e($distribuidore->ciudad); ?>

                        </div>
                        <div class="form-group">
                            <strong>Pais:</strong>
                            <?php echo e($distribuidore->pais); ?>

                        </div>
                        <div class="form-group">
                            <strong>Cp:</strong>
                            <?php echo e($distribuidore->cp); ?>

                        </div>
                        <div class="form-group">
                            <strong>Correo:</strong>
                            <?php echo e($distribuidore->correo); ?>

                        </div>
                        <div class="form-group">
                            <strong>Telefono:</strong>
                            <?php echo e($distribuidore->telefono); ?>

                        </div>
                        <div class="form-group">
                            <strong>Date:</strong>
                            <?php echo e($distribuidore->date); ?>

                        </div>
                        <div class="form-group">
                            <strong>Matriculaid:</strong>
                            <?php echo e($distribuidore->matriculaid); ?>

                        </div>
                        <div class="form-group">
                            <strong>Matriculaid2:</strong>
                            <?php echo e($distribuidore->matriculaid2); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vacationcards\resources\views/distribuidore/show.blade.php ENDPATH**/ ?>