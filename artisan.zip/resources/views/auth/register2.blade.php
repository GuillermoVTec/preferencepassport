@extends('layouts.app')

@section('content')


                 <h4 class="fw-bold py-3 mb-4"> <i class="bx bx-user me-1"></i> Agregar Distribuidor</h4>

                <div class="row">
                <div class="col-md-12">
                  <div class="card mb-4">
                    <h5 class="card-header">Detalles del Distribuidor</h5>
                    <form enctype="multipart/form-data" method="POST" action="{{ route('register') }}">
                        @csrf


                <div class="card-body">
                     @if ($message = Session::get('success'))
                        <div class="alert alert-success">
                            <p>{{ $message }}</p>
                        </div>
                    @endif
                <div>
                 <div class="d-flex align-items-start align-items-sm-center gap-4">
                        <img
                          src="assets/img/avatars/1.png"
                          alt="user-avatar"
                          class="d-block rounded"
                          height="100"
                          width="100"
                          id="uploadedAvatar"
                          name="avatar2"                        />

                        <div class="button-wrapper">

                          <label for="avatarFile" class="btn btn-primary me-2 mb-4" tabindex="0">
                            <span class="d-none d-sm-block">Foto de Perfil</span>
                            <i class="bx bx-upload d-block d-sm-none"></i>
                            <input
                              

                              type="file"
                              id="avatarFile"
                              name="avatar"
                              class="account-file-input"
                              hidden
                              accept="image/png, image/jpeg"
                            />
                          </label>

                          <button type="button" class="btn btn-outline-secondary account-image-reset mb-4">
                            <i class="bx bx-reset d-block d-sm-none"></i>
                            <span class="d-none d-sm-block">Restaurar</span>
                          </button>

                          <p class="text-muted mb-0">Acepta JPG, GIF or PNG. Tamaño Max. 800K</p>
                        </div>
                      </div>
                    </div> 
                 </div>
                  <hr class="my-0">
                    <div class="card-body">

                        <div class="row">
                            
                        <div class="mb-3 col-md-6">
                                      {{ Form::label('razonsocial') }}
                                      {{ Form::text('razonsocial', 'razonsocial', ['class' => 'form-control' . ($errors->has('razonsocial') ? ' is-invalid' : ''), 'placeholder' => 'Razonsocial']) }}
                                      {!! $errors->first('razonsocial', '<div class="invalid-feedback">:message</div>') !!}
                        </div>
                        <div class="mb-3 col-md-6">
                                     {{ Form::label('representantelegal') }}
                                     {{ Form::text('representantelegal', 'representantelegal', ['class' => 'form-control' . ($errors->has('representantelegal') ? ' is-invalid' : ''), 'placeholder' => 'Representantelegal']) }}
                                     {!! $errors->first('representantelegal', '<div class="invalid-feedback">:message</div>') !!}
                        </div>
                        <div class="mb-3 col-md-6">
                                      {{ Form::label('rfc') }}
                                      {{ Form::text('rfc', 'rfc', ['class' => 'form-control' . ($errors->has('rfc') ? ' is-invalid' : ''), 'placeholder' => 'Rfc']) }}
                                      {!! $errors->first('rfc', '<div class="invalid-feedback">:message</div>') !!}
                        </div>
                        <div class="mb-3 col-md-6">
                                      {{ Form::label('direccion') }}
                                      {{ Form::text('direccion', 'direccion', ['class' => 'form-control' . ($errors->has('direccion') ? ' is-invalid' : ''), 'placeholder' => 'Direccion']) }}
                                      {!! $errors->first('direccion', '<div class="invalid-feedback">:message</div>') !!}
                        </div>
                        <div class="mb-3 col-md-4">
                                     {{ Form::label('ciudad') }}
                                     {{ Form::text('ciudad', 'ciudad', ['class' => 'form-control' . ($errors->has('ciudad') ? ' is-invalid' : ''), 'placeholder' => 'Ciudad']) }}
                                     {!! $errors->first('ciudad', '<div class="invalid-feedback">:message</div>') !!}
                        </div>
                        <div class="mb-3 col-md-4">
                                    {{ Form::label('pais') }}
                                    {{ Form::text('pais', 'pais', ['class' => 'form-control' . ($errors->has('pais') ? ' is-invalid' : ''), 'placeholder' => 'Pais']) }}
                                    {!! $errors->first('pais', '<div class="invalid-feedback">:message</div>') !!}
                        </div>
                        <div class="mb-3 col-md-4">
                                    {{ Form::label('cp') }}
                                    {{ Form::text('cp', 'cp', ['class' => 'form-control' . ($errors->has('cp') ? ' is-invalid' : ''), 'placeholder' => 'Cp']) }}
                                    {!! $errors->first('cp', '<div class="invalid-feedback">:message</div>') !!}
                        </div>


                        <div class="mb-3 col-md-4">
                                     {{ Form::label('telefono') }}
                                     {{ Form::text('telefono', 'telefono', ['class' => 'form-control' . ($errors->      has('telefono') ? ' is-invalid' : ''), 'placeholder' => 'Telefono']) }}
                                    {!! $errors->first('telefono', '<div class="invalid-feedback">:message</div>') !!}
                        </div>
                        <div class="mb-3 col-md-4">
                                    {{ Form::label('Fecha de inicio de Contrato') }}
                                    {{ Form::date('date', 'date', ['class' => 'form-control' . ($errors->has('date') ? '       is-invalid' : ''), 'placeholder' => 'Date','id'=>"html5-date-input"]) }}
                                    {!! $errors->first('date', '<div class="invalid-feedback">:message</div>') !!}
                        </div>
                        <div class="mb-3 col-md-4">
                                    {{ Form::label('matriculaid') }}
                                    {{ Form::text('matriculaid', 'matriculaid', ['class' => 'form-control' . ($errors->has('matriculaid') ? ' is-invalid' : ''), 'placeholder' => 'Matriculaid']) }}
                                    {!! $errors->first('matriculaid', '<div class="invalid-feedback">:message</div>') !!}
                        </div>
                        </div>
                        <hr class="my-0" />
                        
                        <h5 class="card-header">Accesos</h5>
                         <div class="row">
                        <div class="mb-3 col-md-6">
                                <label >{{ __('Nombre de usuario') }}</label>
                                <input id="name" type="text" class="form-control @error('name') is-invalid @enderror" name="name" value="{{ old('name') }}" required autocomplete="name" autofocus>

                                @error('name')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            
                        </div>
                        <div class="mb-3 col-md-6">
                            <label >{{ __('Correo electronico') }}</label>
                                <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email">

                                @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                        </div>
                        <div class="mb-3 col-md-4">
                            <label for="password" class="col-md-4 col-form-label text-md-end">{{ __('Password') }}</label>

                            
                                <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="new-password">

                                @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            

                        </div>
                        <div class="mb-3 col-md-4">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-end">{{ __('Confirm Password') }}</label>

                           
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                            
                        </div>

                        <div class="mb-3 col-md-4 ">
                        <label class="col-md-4 col-form-label text-md-end">Rol:</label>
                    
                        <select name='roles' class="form-select" id="exampleFormControlSelect1">
                        
                        <option value="Distribuidor">Distribuidor</option>
                        
                        </select>
                        
                       
                         </div>
                       
                            <div class="mt-2">
                                <button type="submit" class="btn btn-primary me-2">
                                    {{ __('Register') }}
                                </button>
                           <a class="btn btn-primary me-2" href="{{ route('home') }}"> Back</a>
                        </div>

                    </form>
                                    </div>
                    <!-- /Account -->
                  </div>
                </div>
              </div>
            </div>
          
@endsection

