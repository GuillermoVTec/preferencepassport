

@extends('layouts.app')

@section('template_title')
    Lead Admin
@endsection

@section('content')
     <h4 class="fw-bold py-3 mb-4"> <i class="bx bx-bx bx-detail me-1"></i> Asignación lead</h4>
     
              <div class="row">
            <div class="card">
                <div class="col-xl">

                    @if ($message = Session::get('success'))
                        <div class="alert alert-success">
                            <p>{{ $message }}</p>
                        </div>
                    @endif
                   <form >
                       @csrf
                    
                      <div class="card-header d-flex justify-content-between align-items-center">                  
                      <small class="text-muted float-end">Distribuidor
                      <div class="input-group input-group-merge">
                        <select id="select2" name="matriculaid" aria-hidden="true"  class="form-select input-sm select2 select2-hidden-accessible">
                         
                            <option value=""> Todos </option> 
                                @foreach ($distribuidores as  $distribuidor)
                                          <option value="{{ $distribuidor->id }}"> {{ $distribuidor->name."-".$distribuidor->roles()->first()->name}} </option> 
                                @endforeach
                        </select>
                       </div> 
                       </small>
                        <small class="text-muted float-end">Estado
                        <div class="input-group input-group-merge">
                        <select id="status" name="status"  class="form-select form-select-sm">
                         
                            <option value=""> Todos </option> 
                                @foreach ($status as  $statu)
                                          <option value="{{ $statu->id }}"> {{ $statu->nombre}} </option> 
                                @endforeach
                        </select>
                        </div> 
                        <button id="showToastPlacement" class="btn btn-outline-primary d-block">Buscar</button>

                        
                     
                     
                      
                      </small>
                      </form>
                 <form  method="get" action="{{ route('lead.asignar') }}" enctype="multipart/form-data">
                     @csrf
                    @if ($message = Session::get('danger'))
                        <div class="alert alert-danger">
                            <p>{{ $message }}</p>
                        </div>
                    @endif
                   
                      <input class="form-input form-input-sm" name="nlead" id="nlead" placeholder="Numero de leads">
    
                               
                    </input>
                    <select id="matriculaid" name="matriculaid"  class="form-select form-select-sm">
                         
                            <option value=""> Seleccionar usario </option> 
                                @foreach ($distribuidores as  $distribuidor)
                                          <option value="{{ $distribuidor->id }}"> {{ $distribuidor->name."-".$distribuidor->roles()->first()->name}} </option> 
                                @endforeach
                        </select>
                      
                    <select id="statusb" name="statusb"  class="form-select form-select-sm">
                         
                            <option value="">Selecione estado de los leads a asignar. </option> 
                                @foreach ($status as  $statu)
                                          <option value="{{ $statu->id }}"> {{ $statu->nombre}} </option> 
                                @endforeach
                  </select>
                  <select id="Uventas" name="Uventas"  class="form-select form-select-sm">
                         
                            <option value="">Selecione al vendedor. </option> 
                                @foreach ($usuariosConRol as  $usuarios)
                                          <option value="{{ $usuarios->id }}"> {{ $usuarios->name}} </option> 
                                @endforeach
                  </select>
                  <button id="showToastPlacement" class="btn btn-outline-primary d-block">Buscar</button>
                  </form>

                  </div>  


                  </div>
                
                    
                        
                         <small class="text-muted float-end">

                 </small>
                
                             
                
                </h5>
                        <div class="table-responsive text-nowrap">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>✏️ ID</th>
                                        
										<th>👨🏻‍💻 Nombre</th>
										<th>Edad</th>
										
										<th>📱 Telefono</th>
										
										<th>✉️ Correo</th>
										<th>🌐 País</th>
                                        <th>🌐 Fecha de creacion</th>
                                        <th>🌐 Estado</th>
                                       
										
						

                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody class="table-border-bottom-0">
                               
                                    @foreach ($leads as $lead)
                                        <tr>
                                           
                                            @if(isset($lead->User->distribuidore->matriculaid))
                                            <td><i class="fab fa-angular fa-lg text-danger me-3"></i><strong>{{'000'.$lead->User->distribuidore->matriculaid.$lead->User->distribuidore->id}}</strong></td>
                                                                
                                            @else
                                              <td><i class="fab fa-angular fa-lg text-danger me-3"></i><strong>{{'000'.'VC'.$lead->User->id}}</strong></td>
                                            @endif
											<td>{{ $lead->nombre }}</td>
											<td>{{ $lead->edad }}</td>
											
											<td>{{ $lead->telefono1 }}</td>
											
											<td>{{ $lead->correo }}</td>
											<td>{{ $lead->pais }}</td>
                                            <td>{{ $lead->created_at->format('d-m-Y') }}</td>
                                            

                                                 @if($lead->statuses_id == '1')
                                            <td ><span class=" badge bg-label-warning me-1">{{ $lead->statuses->nombre}} </span> </font></td>
                                                @elseif($lead->statuses_id == '2')
                                            <td><span class="badge bg-label-info me-1">{{ $lead->statuses->nombre}} </span>  </font></td>
                                                @elseif($lead->statuses_id == '3')
                                            <td> <span class="badge bg-label-danger me-1">{{ $lead->statuses->nombre}} </span> </font></td>
                                                @elseif($lead->statuses_id == '4')
                                            <td><span class="badge bg-label-danger me-1 ">{{ $lead->statuses->nombre}} </span> </font></td>
                                                @elseif($lead->statuses_id == '5')
                                            <td> <span class=" badge bg-label-success me-1">{{ $lead->statuses->nombre}} </span>  </td>
                                                @else($lead->statuses_id == '6')
                                                <td> <span class="badge bg-label-danger me-1">{{ $lead->statuses->nombre}} </span> </font></td>
                                                 @endif
										

                                            <td>
                                                <div >
                                                 <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                                                 <i class="bx bx-dots-vertical-rounded"></i>
                                                </button>
                                                <div class="dropdown-menu">
                                                <form action="{{ route('lead.destroy',$lead->id) }}" method="POST">
                                                    <a class="dropdown-item" href="{{ route('lead.show',$lead->id) }}"><i class="bx bx-show-alt me-1"></i> Ver</a>
                                                    
                                                    <a class="dropdown-item" href="{{ route('lead.edit',$lead->id) }}"><i class="bx bx-edit-alt me-1"></i> Editar </a>
                                                    
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit"class="dropdown-item"><i class="bx bx-trash me-1"></i>Eliminar </button>
                                                </form>
                                                 </div>
                                          </div>
                                            </td>
                                        </tr>
                                    @endforeach
                                  
                                </tbody>
                            </table>
                            {{ $leads->links() }}

                        </div>
                    </div>
                </div>
               
            </div>
        </div>
   
@endsection
