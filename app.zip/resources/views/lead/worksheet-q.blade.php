@extends('layouts.app')

@section('template_title')
    
@endsection

@section('content')
       <h4 class="fw-bold py-3 mb-4"> <i class="bx bx-user me-1"></i> WORKSHEET - Q</h4>
        <div class="">
            <div class="col-md-12">

                @includeif('partials.errors')

                <div class="card card-default">
                    <div class="card-header">
                         @role('Distribuidor')
                             <h5 class=""><small class="text-muted float-end"><a class="btn btn-primary"  href="{{ route('lead.show',$lead->id) }}">Regresar</a></small></h5>
                            @else('Administrador')
                           
                            <h5 class=""><small class="text-muted float-end"><a class="btn btn-primary"   href="{{ route('lead.show',$lead->id) }}">Regresar</a></small></h5>
                            @endrole
                       
                        
                    </div>
                    
                    <div class="card-body">
                        
                        <form method="POST" action="{{ route('lead.update', $lead->id) }}"  role="form" enctype="multipart/form-data">
                            {{ method_field('PATCH') }}
                            @csrf
                            <div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y" >
              <h4 class="fw-bold py-3 mb-4"> <i class="></i> </h4>

              <div class="row">
                <div class="col-md-12">
                  <div class="">
                    <h5 class="card-header">Datos del cliente</h5>
                    <!-- Account -->
                   
                    <hr class="my-0" />
                    <div class="card-body">
                      <form id="formAccountSettings" method="POST" onsubmit="return false">
                        <div class="row">
                          <div class="mb-3 col-md-1">
                            <label class="form-label">ID LEAD:</label>
                            <p class="fw-semibold fs-5">{{$lead->id}}</p>
                          </div>
                          <div class="mb-3 col-md-1">
                            <label class="form-label">REGISTRO:</label>
                            <p class="fw-semibold fs-6">{{$date}}</p>
                          </div>
                          <div class="mb-3 col-md-2">
                            <label class="form-label">VENDEDOR:</label>
                            <p class="fw-semibold fs-6"> {{ Auth::user()->name }}</p>
                          </div>
                          <div class="mb-3 col-md-2">
                            <label class="form-label">CERRADOR:</label>
                            <p class="fw-semibold fs-6"> Alma Pereira</p>
                          </div>
                          <div class="mb-2 col-md-1">
                            <label class="form-label">ESTATUS:</label>
                                                 @if($lead->statuses_id == '1')
                                          <p class="fw-semibold fs-6"><b><span class="badge bg-label-primary ">{{ $lead->statuses->nombre}} </span> </font></b></p>
                                                @elseif($lead->statuses_id == '2')
                                          <p class="fw-semibold fs-6"><b><span class="badge bg-label-info ">{{ $lead->statuses->nombre}} </span> </font></b></p>
                                                @elseif($lead->statuses_id == '3')
                                          <p class="fw-semibold fs-6"><b><span class="badge bg-label-danger me-1">{{ $lead->statuses->nombre}} </span> </font></b></p>
                                                @elseif($lead->statuses_id == '4')
                                          <p class="fw-semibold fs-6"><b><span class="badge bg-label-warning ">{{ $lead->statuses->nombre}} </span> </font></b></p>
                                                @else($lead->statuses_id == '5')
                                          <p class="fw-semibold fs-6"><b><span class="badge bg-label-success ">{{ $lead->statuses->nombre}} </span></b></p>
                                                 @endif
                          </div>
                          <div class="mb-3 col-md-1">
                            <label class="form-label">CALIF:</label>
                             <select class="form-select" id="exampleFormControlSelect1">
                            <option value="1">Q</option>
                            <option value="2">NQ</option>
                            </select>
                          </div>
                          <div class="mb-3 col-md-2">
                            <label class="form-label" for="phoneNumber">#BOOKING:</label>
                            <div class="input-group input-group-merge">
                              <input type="text" class="form-control" value="093849"/>
                            </div>
                          </div>
                           <!-- Content 
                          <div class="mb-3 col-md-3">
                            <label class="form-label" for="phoneNumber">CALIFICACIÓN:</label>
                             <select class="form-select" id="exampleFormControlSelect1">
                            <option selected >Seleccionar</option>
                            <option value="1">Q</option>
                            <option value="2">NQ</option>
                            </select>
                          </div>-->
                          <div class="mb-3 col-md-2">
                            <label class="form-label" for="phoneNumber">FECHA DE COMPRA:</label>
                            <div class="input-group input-group-merge">
                             <input class="form-control" type="date" value="" id="html5-date-input" />
                            </div>
                          </div>
                           <hr class="my-0 mb-4" />
                          <div class="mb-3 col-md-5">
                            <label class="form-label">Titular:</label>
                            <input class="form-control" type="text" id="name" value="{{$lead->nombre}}"/>
                          </div>
                          <div class="mb-3 col-md-2">
                            <label class="form-label">Edad:</label>
                            <input class="form-control" type="text" value="{{$lead->edad}}" />
                          </div>
                          <div class="mb-3 col-md-3">
                            <label  class="form-label">OCUPACIÓN:</label>
                            <input class="form-control" type="text" />
                          </div>
                          <div class="mb-3 col-md-2">
                            <label  class="form-label">ESTADO CIVIL:</label>
                            <select class="form-select" id="exampleFormControlSelect1">
                            <option selected value="{{$lead->estadocivil}}">{{$lead->estadocivil}}</option>
                            <option value="Soltero">Soltero (a)</option>
                            <option value="v">Union Libre</option>
                            <option value="Viudo">Viudo (a)</option>
                            </select>
                          </div>
                          <div class="mb-3 col-md-5">
                            <label class="form-label">Cotitular:</label>
                            <input class="form-control" type="text" id="name"/>
                          </div>
                          <div class="mb-3 col-md-2">
                            <label class="form-label">Edad:</label>
                            <input class="form-control" type="text"/>
                          </div>
                          <div class="mb-3 col-md-3">
                            <label  class="form-label">OCUPACIÓN:</label>
                            <input class="form-control" type="text" />
                          </div>
                          <div class="mb-3 col-md-2">
                            <label  class="form-label">ESTADO CIVIL:</label>
                            <select class="form-select" id="exampleFormControlSelect1">
                            <option selected>Casado (a)</option>
                            <option value="1">Soltero (a)</option>
                            <option value="2">Union Libre</option>
                            <option value="1">Viudo (a)</option>
                            </select>
                          </div>
                          <div class="mb-3 col-md-3">
                            <label class="form-label">INGRESOS:</label>
                            <input type="text" class="form-control"/>
                          </div>
                          <div class="mb-3 col-md-3">
                           <label class="form-label">TARJETAS:</label>
                            <input class="form-control" type="text" />
                          </div>
                          <div class="mb-3 col-md-3">
                            <label class="form-label">TELEFONO 1:</label>
                            <input class="form-control" type="text" id="phoneNumber" value="{{$lead->telefono1}}"/>
                          </div>
                          <div class="mb-3 col-md-3">
                            <label for="zipCode" class="form-label">TELEFONO 2:</label>
                            <input type="text" class="form-control" id="phoneNumber" value="{{$lead->telefono2}}"/>
                          </div>

                          <div class="mb-3 col-md-3">
                            <label class="form-label">CORREO ELECTRONICO:</label>
                            <input type="email" class="form-control" id="emeal" name="email" value="{{$lead->correo}}"/>
                          </div>
                          <div class="mb-3 col-md-3">
                            <label class="form-label" for="country">PAÍS:</label>
                            <div class="input-group input-group-merge">
                              <input type="text" id="country" class="form-control" value="{{$lead->pais}}"/>
                            </div>
                          </div>
                          <div class="mb-3 col-md-3">
                            <label class="form-label" for="phoneNumber">CIUDAD:</label>
                            <div class="input-group input-group-merge">
                              <input type="text" id="city"  class="form-control"/>
                            </div>
                          </div>
                           <div class="mb-3 col-md-3">
                            <label class="form-label">C.P:</label>
                            <div class="input-group input-group-merge">
                              <input type="text" id="zipcode" class="form-control" maxlength="6"/>
                            </div>
                          </div>

                          <hr class="my-0" />
                          <h5 class="card-header">DATOS DE RESERVA</h5>
                          <div class="mb-3 col-md-2">
                            <label class="form-label">DESTINO:</label>
                            <input class="form-control" type="text"/>
                          </div>
                          <div class="mb-3 col-md-3">
                            <label class="form-label">HOTEL:</label>
                            <input class="form-control" type="text"/>
                          </div>
                          <div class="mb-4 col-md-2">
                            <label class="form-label" for="phoneNumber">TIPO DE FECHA:</label> <br>
                            <input class="form-input" type="checkbox" id="ocultar-mostrar"/>
                            <label class="form-label" for="flexSwitchCheckDefault">Fecha Abierta</label> <br>
                          </div>
                          <div class="mb-3 col-md-1">
                            <label class="form-label">#NOCHES:</label>
                             <select class="form-select" id="exampleFormControlSelect1">
                            <option selected value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="3">4</option>
                            <option value="3">5</option>
                            <option value="3">6</option>
                            <option value="3">7</option>
                            <option value="3">8</option>
                            <option value="3">9</option>
                            <option value="3">10</option>
                            <option value="3">11</option>
                            <option value="3">12</option>
                            </select>
                          </div>
                         <div id='ocultar-y-mostrar' class="mb-3 col-md-4">
                          <div class="col-md-5">
                            <label class="form-label" for="phoneNumber">CHECK IN:</label>
                            <div class="input-group input-group-merge">
                             <input class="form-control" type="date" value="0000-00-000" id="html5-date-input" />
                            </div>
                          </div>
                          <div class="col-md-5" style="float: right; margin-top: -60px;">
                            <label class="form-label" for="phoneNumber">CHECK OUT:</label>
                            <div class="input-group input-group-merge">
                             <input class="form-control" type="date" value="0000-00-000" id="html5-date-input" />
                            </div>
                          </div>
                         </div>

                          
                          <div class="mb-3 col-md-3">
                            <label class="form-label">HABITACIONES:</label>
                            <input class="form-control" type="text"/>
                          </div>
                          <div class="mb-3 col-md-3">
                            <label class="form-label">TIPO DE HABITACIÓN:</label>
                            <input class="form-control" type="text"/>
                          </div>
                          <div class="mb-3 col-md-1">
                            <label class="form-label" for="phoneNumber">ADULTOS:</label>
                            <select class="form-select" id="exampleFormControlSelect1">
                            <option selected value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="3">4</option>
                            <option value="3">5</option>
                            <option value="3">6</option>
                            </select>
                          </div>
                          <div class="mb-3 col-md-1">
                            <label class="form-label" for="phoneNumber">MENORES:</label>
                            <select class="form-select" id="exampleFormControlSelect1">
                            <option selected value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="3">4</option>
                            <option value="3">5</option>
                            <option value="3">6</option>
                            </select>
                          </div>
                          <div class="mb-3 col-md-1">
                            <label class="form-label">EDADES:</label>
                            <div class="input-group input-group-merge">
                              <input type="text" class="form-control"/>
                            </div>
                          </div>
                          <div class="mb-3 col-md-3">
                            <label class="form-label">PLAN DE ALIMENTOS:</label>
                            <div class="input-group input-group-merge">
                              <input type="text" class="form-control"/>
                            </div>
                          </div>
                          <hr>
                          <!-- Merged -->
                          <div class="col-md-6">
                            <div class=" mb-4">
                              <h5 class="card-header">DATOS DE TARIFAS
                                <small class="text-muted float-end">Moneda
                                  <select id="smallSelect" class="form-select form-select-sm">
                                    <option>USD</option>
                                    <option value="1">MXN</option>
                                  </select>
                                </small>
                              </h5>

                              <div class="card-body demo-vertical-spacing demo-only-element">
                                <div class="form-password-toggle">
                                  <label class="form-label" for="basic-default-password32">COSTO TOTAL:</label>
                                  <div class="input-group input-group-merge">
                                  <span class="input-group-text">$</span>
                                  <input
                                    type="text"
                                    class="form-control"
                                    placeholder="100"
                                    aria-label="Cantidad (en dolares)" 
                                  />
                                  <span class="input-group-text">.00</span>
                                  </div>
                                </div>

                                 <div class="form-password-toggle">
                                  <label class="form-label">PACKEO AGENTE:</label>
                                  <div class="input-group input-group-merge">
                                   <input type="text" class="" id="basic-default-name" style="border-bottom: solid 1px #ccc !important; border: none; border-radius: none; width: 100%;"/>
                                  </div>
                                </div>

                                <div class="form-password-toggle">
                                  <label class="form-label" for="basic-default-password32">ACTIVACIÓN:</label>
                                  <div class="input-group input-group-merge">
                                   <input type="text" class="" id="basic-default-name" style="border-bottom: solid 1px #ccc !important; border: none; border-radius: none; width: 100%;"/>
                                  </div>
                                </div>

                                <div class="form-password-toggle">
                                  <label class="form-label" for="basic-default-password32">RESORT FEE:</label>
                                  <div class="input-group input-group-merge">
                                   <input type="text" class="" id="basic-default-name" style="border-bottom: solid 1px #ccc !important; border: none; border-radius: none; width: 100%;"/>
                                  </div>
                                </div>

                               <div class="form-password-toggle">
                                  <label class="form-label" for="basic-default-password32">PAGO INICIAL:</label>
                                  <div class="input-group input-group-merge">
                                   <input type="text" class="" id="basic-default-name" style="border-bottom: solid 1px #ccc !important; border: none; border-radius: none; width: 100%;"/>
                                  </div>
                                </div>

                                <div class="form-password-toggle">
                                  <label class="form-label" for="basic-default-password32">PENDIENTE DE PAGO:</label>
                                  <div class="input-group input-group-merge">
                                   <input type="text" class="" id="basic-default-name" style="border-bottom: solid 1px #ccc !important; border: none; border-radius: none; width: 100%;"/>
                                  </div>
                                </div>
                                <div class="form-password-toggle">
                                  <label class="form-label" for="basic-default-password32">FECHA LIMITE DE PAGO:</label>
                                  <div class="input-group input-group-merge">
                                  <input class="form-control" type="date" value="0000-00-000" id="html5-date-input" />
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <!-- Merged -->
                          <div class="col-md-6">
                            <div class="mb-4">
                              <h5 class="card-header">FORMAS DE PAGO</h5>
                              <div class="card-body demo-vertical-spacing demo-only-element">
                                <div class="form-password-toggle">
                                  <label class="form-label" for="basic-default-password32">BANCO:</label>
                                  <div class="input-group input-group-merge">
                                    <input type="text" class="" id="basic-default-name" style="border-bottom: solid 1px #ccc !important; border: none; border-radius: none; width: 100%;"/>
                                  </div>
                                </div>
                                <div class="form-password-toggle">
                                  <label class="form-label" for="basic-default-password32">TITULAR:</label>
                                  <div class="input-group input-group-merge">
                                    <input type="text" class="" id="basic-default-name" style="border-bottom: solid 1px #ccc !important; border: none; border-radius: none; width: 100%;"/>
                                  </div>
                                </div>

                                <div class="mb-3 col-md-6">
                                  <label class="form-label">AFILIACION:</label><br>
                                  <div class="form-check form-check-inline mt-2">
                                  <input class="form-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1"/>
                                  <label class="form-label" for="inlineRadio1">VISA</label>
                                </div>
                                <div class="form-check form-check-inline">
                                  <input class="form-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2"/>
                                  <label class="form-label" for="inlineRadio2">MC</label>
                                </div>
                                 <div class="form-check form-check-inline">
                                  <input class="form-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2"/>
                                  <label class="form-label" for="inlineRadio2">AMEX</label>
                                </div>
                                </div>

                                <div class="form-password-toggle">
                                  <label class="form-label" for="basic-default-password32">16 DIGITOS:</label>
                                  <div class="input-group input-group-merge">
                                    <input type="text" class="" id="basic-default-name" style="border-bottom: solid 1px #ccc !important; border: none; border-radius: none; width: 100%;"/>
                                  </div>
                                </div>
                                <div class="mb-3 col-md-7">
                                  <label class="form-label">VIGENCIA:</label>
                                  <div class="input-group">
                                        <input type="text" class="form-control validar"  name="expiremonth" maxlength="2">
                                        <input type="text" class="form-control validar"  name="expireyear" maxlength="2">
                                  </div>
                                </div>
                                <div class="mb-3 col-md-4" style="float: right; margin-top:-68px !important;">
                                  <label class="form-label">CVV:</label>
                                  <input class="form-control validar" type="text" maxlength="4"/>
                                </div>

                                <div>
                                 <label for="exampleFormControlTextarea1" class="form-label">NOTAS:</label>
                                 <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                                </div>
                              </div>
                            </div>
                          </div>
                          <hr>
                          <h5 class="card-header">DETALLES DE PAGO</h5>
                          
                          <table class="table table-striped">
                            
                            <thead>
                              <tr>
                                <th>Fecha</th>
                                <th>Concepto</th>
                                <th>Cantidad</th>
                                <th>Tarjeta</th>
                                <th>16 Digitos</th>
                                <th>Codigo</th>
                                <th>Vencimiento</th>
                                <th>Autorización</th>
                                <th>Operador</th>
                                <th>Comprobante</th>
                              </tr>
                            </thead>
                            <tbody style="font-size: 12px !important;">
                              <tr>
                                <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>12-12-1212</strong></td>
                                 <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>Paquete</strong></td>
                                 <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>$999 USD</strong></td>
                                 <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>Visa</strong></td>
                                 <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>**** **** **** 9089</strong></td>
                                 <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>**7</strong></td>
                                 <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>07/23</strong></td>
                                 <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>1678499</strong></td>
                                 <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>Juan Pablo</strong></td>
                                 <td>
                                    <ul class="list-unstyled users-list m-0 avatar-group d-flex align-items-center">
                                      <li  class="avatar " style="width:80px; height: 80px;" >
                                        <img src="{{asset('assets/img/comprobante.jpg')}}" alt="Avatar" class="rounded-circle"  data-bs-toggle="modal" data-bs-target="#basicModal"/>
                                        <!-- Button trigger modal -->
                                      </li>
                                    </ul>
                                  </td>
                              </tr>
                              <tr>
                                <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>12-12-1212</strong></td>
                                 <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>Paquete</strong></td>
                                 <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>$999 USD</strong></td>
                                 <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>Visa</strong></td>
                                 <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>**** **** **** 9089</strong></td>
                                 <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>**7</strong></td>
                                 <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>07/23</strong></td>
                                 <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>1678499</strong></td>
                                 <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong>Juan Pablo</strong></td>
                                 <td>
                                    <ul class="list-unstyled users-list m-0 avatar-group d-flex align-items-center">
                                      <li  class="avatar " style="width:80px; height: 80px;" >
                                        <img src="{{asset('assets/img/comprobante.jpg')}}" alt="Avatar" class="rounded-circle"  data-bs-toggle="modal" data-bs-target="#basicModal"/>
                                        <!-- Button trigger modal -->
                                      </li>
                                    </ul>
                                  </td>
                              </tr>
                              
                            </tbody>
                          </table>
                           <!-- fin Modal -->
                              <div class="modal fade" id="basicModal" tabindex="-1" aria-hidden="true">
                                <div class="modal-dialog" >
                                  <div class="modal-content">
                                    <div class="modal-header">
                                      <h5 class="modal-title" id="exampleModalLabel1">Comprobante de Pago</h5>
                                      <button
                                        type="button"
                                        class="btn-close"
                                        data-bs-dismiss="modal"
                                        aria-label="Close"
                                      ></button>
                                    </div>
                                    <div class="modal-body">
                                       <img src="assets/img/comprobante.jpg" alt="Avatar" width="100%" />
                                    </div>
                                    <div class="modal-footer">
                                      <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                                        Close
                                      </button>
                                     
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <!-- fin Modal -->
                              <hr>
                              <div class="collapse" id="collapseExample" style="background-color: #fff !important;">
                                <div class="d-grid d-sm-flex p-3" >
                                  
                                 <!-- Merged -->
                          <div class="col-md-6">
                            <div class=" mb-4">
                              <h5 class="card-header">REALIZAR UN PAGO
                                <small class="text-muted float-end">Moneda
                                  <select id="smallSelect" class="form-select form-select-sm">
                                    <option>USD</option>
                                    <option value="1">MXN</option>
                                  </select>
                                </small>
                              </h5>

                              <div class="card-body demo-vertical-spacing demo-only-element">
                                <div class="form-password-toggle">
                                  <label class="form-label" for="basic-default-password32">FECHA DE PAGO:</label>
                                  <div class="input-group input-group-merge">
                                  <input class="form-control" type="date" value="0000-00-000" id="html5-date-input" />
                                  </div>
                                </div>
                                <div class="form-password-toggle">
                                  <label class="form-label" for="basic-default-password32">CANTIDAD:</label>
                                  <div class="input-group input-group-merge">
                                  <span class="input-group-text">$</span>
                                  <input
                                    type="text"
                                    class="form-control"
                                    placeholder="100"
                                    aria-label="Cantidad (en dolares)" 
                                  />
                                  <span class="input-group-text">.00</span>
                                  </div>
                                </div>

                                 <div class="form-password-toggle">
                                  <label class="form-label">CONCEPTO:</label>
                                  <div class="input-group input-group-merge">
                                   <input type="text" class="" id="basic-default-name" style="border-bottom: solid 1px #ccc !important; border: none; border-radius: none; width: 100%;"/>
                                  </div>
                                </div>

                                <div class="form-password-toggle">
                                  <label class="form-label" for="basic-default-password32">ESTATUS DE PAGO:</label>
                                  <div class="input-group input-group-merge">
                                   <select id="currency" class="select2 form-select">
                                    <option value="">Seleccionar</option>
                                    <option value="usd">Pendiente de Pago</option>
                                    <option value="euro">Pagado</option>
                                    <option value="pound">Devolución</option>
                                  </select>
                                  </div>
                                </div>

                                <div class="form-password-toggle">
                                  <label class="form-label" for="basic-default-password32">PAGO ASIGNADO A:</label>
                                  <div class="input-group input-group-merge">
                                   <input type="text" class="" id="basic-default-name" style="border-bottom: solid 1px #ccc !important; border: none; border-radius: none; width: 100%;"/>
                                  </div>
                                </div>

                               <div class="form-password-toggle">
                                  <label class="form-label" for="basic-default-password32">No. DE APROVACION:</label>
                                  <div class="input-group input-group-merge">
                                   <input type="text" class="" id="basic-default-name" style="border-bottom: solid 1px #ccc !important; border: none; border-radius: none; width: 100%;"/>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <!-- Merged -->
                          <div class="col-md-6">
                            <div class="mb-4">
                              <h5 class="card-header">FORMAS DE PAGO</h5>
                              <div class="card-body demo-vertical-spacing demo-only-element">
                                <div class="demo-inline-spacing mt-3">
                                  <div class="list-group">
                                    <label class="list-group-item">
                                      <input class="form-check-input me-1" type="checkbox" value="" />
                                      Misma Tarjeta: <b>**** **** **** 9089</b>
                                    </label>
                                    <label class="list-group-item">
                                            <input class="form-check-input me-1" type="checkbox" value="" data-bs-toggle="collapse"
                                              data-bs-target="#collapseExample3"
                                              aria-expanded="false"
                                              aria-controls="collapseExample3"/>
                                           Nueva Tarjeta
                                        
                                          <div class="collapse" id="collapseExample3" style="background-color: #fff !important;">
                                            <br>
                                            <div class="form-password-toggle">
                                                <label class="form-label" for="basic-default-password32">BANCO:</label>
                                                <div class="input-group input-group-merge">
                                                  <input type="text" class="" id="basic-default-name" style="border-bottom: solid 1px #ccc !important; border: none; border-radius: none; width: 100%;"/>
                                                </div>
                                              </div>
                                              <div class="form-password-toggle">
                                                <label class="form-label" for="basic-default-password32">TITULAR:</label>
                                                <div class="input-group input-group-merge">
                                                  <input type="text" class="" id="basic-default-name" style="border-bottom: solid 1px #ccc !important; border: none; border-radius: none; width: 100%;"/>
                                                </div>
                                              </div>

                                              <div class="mb-3 col-md-6">
                                                <label class="form-label">AFILIACION:</label><br>
                                                <div class="form-check form-check-inline mt-2">
                                                <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1"/>
                                                <label class="form-check-label" for="inlineRadio1">VISA</label>
                                              </div>
                                              <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2"/>
                                                <label class="form-check-label" for="inlineRadio2">MC</label>
                                              </div>
                                               <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2"/>
                                                <label class="form-check-label" for="inlineRadio2">AMEX</label>
                                              </div>
                                              </div>

                                              <div class="form-password-toggle">
                                                <label class="form-label" for="basic-default-password32">16 DIGITOS:</label>
                                                <div class="input-group input-group-merge">
                                                  <input type="text" class="" id="basic-default-name" style="border-bottom: solid 1px #ccc !important; border: none; border-radius: none; width: 100%;"/>
                                                </div>
                                              </div>
                                              <div class="mb-3 col-md-7">
                                                <label class="form-label">VIGENCIA:</label>
                                                <div class="input-group">
                                                      <input type="text" class="form-control validar"  name="expiremonth" maxlength="2">
                                                      <input type="text" class="form-control validar"  name="expireyear" maxlength="2">
                                                </div>
                                              </div>
                                              <div class="mb-3 col-md-4" style="float: right; margin-top:-75px !important;">
                                                <label class="form-label">CVV:</label>
                                                <input class="form-control validar" type="text" maxlength="4"/>
                                              </div>
                                              <button type="submit" class="btn btn-sm  btn-primary me-2">Guardar Información</button>
                                          </div>
                                    </label>
                                    <label class="list-group-item">
                                      <input class="form-check-input me-1" type="checkbox" value="" />
                                      Transferencia
                                    </label>
                                    <label class="list-group-item">
                                      <input class="form-check-input me-1" type="checkbox" value="" />
                                      Pago en Linea
                                    </label>
                                  </div>
                                </div>
                                <div class="card-body">
                                  <p>Comporbante de cargo</p>
                                  <div class="d-flex align-items-start align-items-sm-center gap-4">
                                    <img src="{{asset('assets/img/avatars/1.png')}}" alt="user-avatar" class="d-block rounded" height="100" width="100" id="uploadedAvatar">
                                    <div class="button-wrapper">
                                      <label for="upload" class="btn btn-primary me-2 mb-4" tabindex="0">
                                        <span class="d-none d-sm-block">Subir Comprobante</span>
                                        <i class="bx bx-upload d-block d-sm-none"></i>
                                        <input type="file" id="upload" class="account-file-input" hidden="" accept="image/png, image/jpeg">
                                      </label>
                                      <button type="button" class="btn btn-outline-secondary account-image-reset mb-4">
                                        <i class="bx bx-reset d-block d-sm-none"></i>
                                        <span class="d-none d-sm-block">Cancelar</span>
                                      </button>

                                    </div>
                                  </div>
                                </div>
                                <hr>
                                <h5 class="card-header" style="float:left;">Balance: $150 USD</h5>
                                <button class="btn btn-primary btn-lg" type="button" style="float: right;">Guardar Informacion</button>
                              </div>
                            </div>
                          </div>
                                </div>
                              </div>
                              <p class="demo-inline-spacing">
                                <a class="btn btn-primary me-1" data-bs-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample" style="float:right !important;">
                                  Nuevo Pago
                                </a>
                              </p>
                        <div class="mt-2">
                          <button type="submit" class="btn btn-primary me-2">Guardar Información</button>
                          <button type="reset" class="btn btn-outline-secondary">Cancelar</button>
                        </div>
                      </form>
                    </div>
                    <!-- /Account -->
                  </div>
                </div>
              </div>
            </div>

                        </form>
     
@endsection