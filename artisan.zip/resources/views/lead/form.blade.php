
  


   
     
        <div class="form-group">
            {{ Form::label('nombre') }}
            {{ Form::text('nombre', $lead->nombre, ['class' => 'form-control' . ($errors->has('nombre') ? ' is-invalid' : ''), 'placeholder' => 'Nombre']) }}
            {!! $errors->first('nombre', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="form-group">
            {{ Form::label('edad') }}
            {{ Form::text('edad', $lead->edad, ['class' => 'form-control' . ($errors->has('edad') ? ' is-invalid' : ''), 'placeholder' => 'Edad']) }}
            {!! $errors->first('edad', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="form-group">
            {{ Form::label('estadocivil') }}
            {{ Form::text('estadocivil', $lead->estadocivil, ['class' => 'form-control' . ($errors->has('estadocivil') ? ' is-invalid' : ''), 'placeholder' => 'Estadocivil']) }}
            {!! $errors->first('estadocivil', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="form-group">
            {{ Form::label('telefono1') }}
            {{ Form::text('telefono1', $lead->telefono1, ['class' => 'form-control' . ($errors->has('telefono1') ? ' is-invalid' : ''), 'placeholder' => 'Telefono1']) }}
            {!! $errors->first('telefono1', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="form-group">
            {{ Form::label('telefono2') }}
            {{ Form::text('telefono2', $lead->telefono2, ['class' => 'form-control' . ($errors->has('telefono2') ? ' is-invalid' : ''), 'placeholder' => 'Telefono2']) }}
            {!! $errors->first('telefono2', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="form-group">
            {{ Form::label('correo') }}
            {{ Form::text('correo', $lead->correo, ['class' => 'form-control' . ($errors->has('correo') ? ' is-invalid' : ''), 'placeholder' => 'Correo']) }}
            {!! $errors->first('correo', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="form-group">
            {{ Form::label('pais') }}
            {{ Form::text('pais', $lead->pais, ['class' => 'form-control' . ($errors->has('pais') ? ' is-invalid' : ''), 'placeholder' => 'Pais']) }}
            {!! $errors->first('pais', '<div class="invalid-feedback">:message</div>') !!}
        </div>

        @if(Request::url() === 'http://127.0.0.1:8000/lead/create')
  

        <div class="form-group">
            
            {{ Form::text('user_id', $username, [ 'class' => 'form-control' . ($errors->has('user_id') ? ' is-invalid' : ''),"readonly", "hidden" ,"value" => "username"])  }}
            {!! $errors->first('user_id', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        @endif
       
        <div class="form-group">
             @can('ver status') 
            {{ Form::label('status') }}
            @endcan
            
         <select hidden name='statuses_id' class="form-select" id="exampleFormControlSelect1">
               
                
                <option value="1" selected  >NUEVA</option>
               @can('ver status') 
                <option value="5">ACTIVADO</option>
               
                <option value="2">SEGUIMIENTO</option>
                <option value="3">NO CONTESTO</option>
                <option value="4">NO INTERESADO</option>
               @endcan
        </select>
        {!! $errors->first('statuses_id', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        
         @if(Request::url() === 'http://127.0.0.1:8000/lead/create')
         @else
        @can('ver nota')
        
        <div class="form-group">
            {{ Form::label('nota') }}
            {{ Form::textArea('nota', $nota->nota, ['class' => 'form-control' . ($errors->has('nota') ? ' is-invalid' : ''),'rows'=>5, "value" => "nota->nota"]) }}
            {!! $errors->first('nota', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="form-group">
            {{ Form::label('nota') }}
            {{ Form::text('leads_id', $nota->leads_id, ['class' => 'form-control' . ($errors->has('leads_id') ? ' is-invalid' : '') ,"value" => "nota->leads_id"]) }}
            {!! $errors->first('leads_id', '<div class="invalid-feedback">:message</div>') !!}
        </div>
        <div class="form-group">
            
            {{ Form::text('user', $username2, ['class' => 'form-control' . ($errors->has('user') ? ' is-invalid' : ''),"readonly", "hidden","value" => "username2"]) }}
            {!! $errors->first('user', '<div class="invalid-feedback">:message</div>') !!}
        </div>

        @endcan
        @endif



  
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>

