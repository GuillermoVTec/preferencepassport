@extends('layouts.app')

@section('template_title')
    {{ $distribuidore->name ?? 'Show Distribuidore' }}
@endsection

@section('content')
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Distribuidore</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="{{ route('distribuidores.index') }}"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Razonsocial:</strong>
                            {{ $distribuidore->razonsocial }}
                        </div>
                        <div class="form-group">
                            <strong>Representantelegal:</strong>
                            {{ $distribuidore->representantelegal }}
                        </div>
                        <div class="form-group">
                            <strong>Rfc:</strong>
                            {{ $distribuidore->rfc }}
                        </div>
                        <div class="form-group">
                            <strong>Direccion:</strong>
                            {{ $distribuidore->direccion }}
                        </div>
                        <div class="form-group">
                            <strong>Ciudad:</strong>
                            {{ $distribuidore->ciudad }}
                        </div>
                        <div class="form-group">
                            <strong>Pais:</strong>
                            {{ $distribuidore->pais }}
                        </div>
                        <div class="form-group">
                            <strong>Cp:</strong>
                            {{ $distribuidore->cp }}
                        </div>
                        <div class="form-group">
                            <strong>Correo:</strong>
                            {{ $distribuidore->correo }}
                        </div>
                        <div class="form-group">
                            <strong>Telefono:</strong>
                            {{ $distribuidore->telefono }}
                        </div>
                        <div class="form-group">
                            <strong>Date:</strong>
                            {{ $distribuidore->date }}
                        </div>
                        <div class="form-group">
                            <strong>Matriculaid:</strong>
                            {{ $distribuidore->matriculaid }}
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
