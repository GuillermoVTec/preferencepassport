<?php


//siempre hay que llamar al controlador 
use App\Http\Controllers\CerradorController;
use App\Http\Controllers\PerfilController;
use App\Http\Controllers\LeadController;
use App\Http\Controllers\NotaController;
use App\Http\Controllers\DistribuidoreController;
use App\Http\Controllers\Auth\RegisterController;
use Illuminate\Support\Facades\Storage;
use App\Http\Controllers\UserController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/





Route::get("/", function () {
    return redirect()->route("login");
});











Auth::routes();
//el prefijo /home hace referencia al url y el prefijo index hace referencia al metodo dentro del controller
//Route::get('/home', [LeadsController::class, 'index']);

Route::post('register2', [DistribuidoreController::class, 'register2'])->name('register2')-> middleware ( 'role:Administrador' );
Route::get('register2', [RegisterController::class, 'showRegistrationForm2'])->name('register2')-> middleware ( 'role:Administrador' );
Route::post('register2', [RegisterController::class, 'register2'])->name('register2')-> middleware ( 'role:Administrador' );


Route::get('perfil', [PerfilController::class, 'index'])->name('perfil')-> middleware ( 'auth' );


Route::get('update', [DistribuidoreController::class, 'update'])->name('update')-> middleware ( 'role:Administrador' );
Route::get('show/{distribuidore}', [DistribuidoreController::class, 'show'])->name('show')-> middleware ( 'role:Administrador' );
Route::get('edit/{distribuidore}', [DistribuidoreController::class, 'edit'])->name('edit')-> middleware ( 'role:Administrador' );
Route::resource('distribuidores', DistribuidoreController::class)-> middleware ( 'role:Administrador' );

Route::get('home', [LeadController::class, 'index2'])->name('home')-> middleware ( 'role:Administrador|Ventas|Distribuidor|validacion' );
Route::get('leadsCreate', [LeadController::class, 'create'])->name('leadsCreate')-> middleware ( 'role:Administrador|Distribuidor' );
Route::get('leadAdmin', [LeadController::class, 'index'])->name('indexAdmin')-> middleware ( 'role:Administrador' );

Route::get('leadDist', [LeadController::class, 'index'])->name('indexDist')-> middleware ( 'role:Administrador|Distribuidor' );
//rutas de ventas y admin
Route::get('asignar', [LeadController::class, 'asignar'])->name('asignar')-> middleware ( 'role:Administrador' );
Route::get('reasignar', [LeadController::class, 'reasignar'])->name('reasignar')-> middleware ( 'role:Administrador' );
Route::get('nuevo', [LeadController::class, 'nuevo'])->name('nuevo')-> middleware ( 'role:Administrador|Ventas' );
Route::get('seguimiento', [LeadController::class, 'seguimiento'])->name('seguimiento')-> middleware ( 'role:Administrador|Ventas' );
Route::get('nocontesto', [LeadController::class, 'nocontesto'])->name('nocontesto')-> middleware ( 'role:Administrador|Ventas' );
Route::get('nointeresado', [LeadController::class, 'nointeresado'])->name('nointeresado')-> middleware ( 'role:Administrador|Ventas' );
Route::get('datosincorrectos', [LeadController::class, 'datosincorrectos'])->name('datosincorrectos')-> middleware ( 'role:Administrador|Ventas' );
Route::get('activados', [LeadController::class, 'activados'])->name('activados')-> middleware ( 'role:Administrador|Ventas' );
Route::get('preregistro', [LeadController::class, 'preregistro'])->name('preregistro')-> middleware ( 'role:Administrador|Ventas' );
Route::post('leads.store', [LeadController::class, 'store'])->name('leads.store')-> middleware ( 'role:Administrador|Ventas|Distribuidor' );
Route::post('lead.edit', [LeadController::class, 'edit'])->name('lead.edit')-> middleware ( 'role:Administrador|Ventas' );
Route::post('lead.store', [LeadController::class, 'store'])->name('lead.store')-> middleware ( 'role:Administrador|Ventas' );


Route::get('lead.showCreate/{id}', [LeadController::class, 'showCreate'])->name('lead.showCreate')-> middleware ( 'role:Administrador' );
Route::post('lead.showStore/{id}', [LeadController::class, 'showStore'])->name('lead.showStore')-> middleware ( 'role:Administrador|Ventas' );
Route::post('lead.showUpdate/{id}', [LeadController::class, 'showUpdate'])->name('lead.showUpdate')-> middleware ( 'role:Administrador|Ventas' );
Route::get('editWorksheet/{id}', [LeadController::class, 'editWorksheet'])->name('editWorksheet')-> middleware ( 'role:Administrador|Ventas' );
//Route::get('lead', [LeadController::class, 'storeDist'])->name('leads.store');
//Route::post('lead', [LeadController::class, 'store'])->name('leads.store');
Route::get('lead.asignar', [LeadController::class, 'updateAsignar'])->name('lead.asignar')-> middleware ( 'role:Administrador|Ventas' );
Route::get('lead.reAsignar', [LeadController::class, 'updateReasignar'])->name('lead.reAsignar')-> middleware ( 'role:Administrador|Ventas' );
Route::post('lead.showStore/{id}', [LeadController::class, 'showStore'])->name('lead.showStore')-> middleware ( 'role:Administrador|Ventas' );
Route::resource('lead', LeadController::class)-> middleware ( 'role:Administrador|Ventas' );
Route::get('lead/{lead}', [LeadController::class, 'show'])->name('lead.show')-> middleware ( 'role:Administrador|Ventas|Distribuidor' );
Route::get('lead/{lead}/edit ', [LeadController::class, 'edit'])->name('lead/{lead}/edit ')-> middleware ( 'role:Administrador|Ventas' );

//cerradores

Route::get('CerradorCreate', [CerradorController::class, 'create'])->name('CerradorCreate')-> middleware ( 'role:Administrador' );
Route::get('cerrador', [CerradorController::class, 'index'])->name('cerrador')-> middleware ( 'role:Administrador' );
Route::resource('cerradors', CerradorController::class)-> middleware ( 'role:Administrador' );

Route::resource('users', UserController::class)-> middleware ( 'role:Administrador' );

https://diarioprogramador.com/crear-crud-en-laravel-con-generador-de-cruds/
