<h3>Crear un nuevo distribuidor</h3> 
  @include('livewire.form') 
  <div class="modal-footer">

  <button class="btn btn-success" wire:click='save'> guardar </button>
  <button type="button" class="btn btn-success" wire:click='save'>Guardar distribuidor</button>
  </div>
  