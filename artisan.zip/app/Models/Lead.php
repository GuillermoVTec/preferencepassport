<?php

namespace App\Models;

use App\Models\Nota;
use Illuminate\Database\Eloquent\Model;

/**
 * Class Lead
 *
 * @property $id
 * @property $nombre
 * @property $edad
 * @property $estadocivil
 * @property $telefono1
 * @property $telefono2
 * @property $correo
 * @property $pais
 * @property $created_at
 * @property $updated_at
 * @property $user_id
 * @property $statuses_id
 * @property Statuses $statuses
 * @property User $user
 * @property Nota $Nota
 * @package App
 * @mixin \Illuminate\Database\Eloquent\Builder
 */
class Lead extends Model
{
    
    static $rules = [

		'nombre' => 'required',
		'edad' => 'required',
		'estadocivil' => 'required',
		'telefono1' => 'required',
		'telefono2' => 'required',
		'correo' => 'required',
		'pais' => 'required',
	
		
		'statuses_id' => 'required',
		
    ];

    protected $perPage = 20;

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['nombre','edad','estadocivil','telefono1','telefono2','correo','pais','user_id','statuses_id'];



    
    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function statuses()
    {
        return $this->hasOne('App\Models\Statuses', 'id', 'statuses_id');
    }
    
    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function user()
    {
        return $this->hasOne('App\Models\User', 'id', 'user_id');
    }
     /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */

       public function Nota()
  {
      return $this->hasMany('App\Models\Nota', 'leads_id', 'id');
  }
  
    public function scopeNombres($query, $nombres){
        if($nombres)
            return $query->where('nombre','like',"%$nombres%");
    }
        public function scopeFechas($query,$fecha1, $fecha2){
        if($fecha1&&$fecha2)
            return $query->whereBetween('created_at', [$fecha1, $fecha2]);


    }

}
