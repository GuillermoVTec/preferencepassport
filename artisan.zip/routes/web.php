<?php


//siempre hay que llamar al controlador 

use App\Http\Controllers\LeadController;
use App\Http\Controllers\NotaController;
use App\Http\Controllers\DistribuidoreController;
use App\Http\Controllers\Auth\RegisterController;
use Illuminate\Support\Facades\Storage;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/





Route::get("/", function () {
    return redirect()->route("login");
});











Auth::routes();
//el prefijo /home hace referencia al url y el prefijo index hace referencia al metodo dentro del controller
//Route::get('/home', [LeadsController::class, 'index']);

Route::post('register2', [DistribuidoreController::class, 'register2'])->name('register2')-> middleware ( 'auth' );
Route::get('register2', [RegisterController::class, 'showRegistrationForm2'])->name('register2')-> middleware ( 'auth' );
Route::post('register2', [RegisterController::class, 'register2'])->name('register2')-> middleware ( 'auth' );





Route::get('update', [DistribuidoreController::class, 'update'])->name('update')-> middleware ( 'auth' );
Route::get('show/{distribuidore}', [DistribuidoreController::class, 'show'])->name('show')-> middleware ( 'auth' );
Route::get('edit/{distribuidore}', [DistribuidoreController::class, 'edit'])->name('edit')-> middleware ( 'auth' );
Route::resource('distribuidores', DistribuidoreController::class)-> middleware ( 'auth' );

Route::get('home', [LeadController::class, 'index2'])->name('home')-> middleware ( 'auth' );
Route::get('leads.create', [LeadController::class, 'create'])->name('create')-> middleware ( 'auth' );
Route::get('leadAdmin', [LeadController::class, 'index'])->name('indexAdmin')-> middleware ( 'auth' );
Route::get('leadDist', [LeadController::class, 'index'])->name('indexDist')-> middleware ( 'auth' );
Route::post('leads.store', [LeadController::class, 'store'])->name('leads.store')-> middleware ( 'auth' );

//Route::get('lead', [LeadController::class, 'storeDist'])->name('leads.store');
//Route::post('lead', [LeadController::class, 'store'])->name('leads.store');


Route::resource('lead', LeadController::class)-> middleware ( 'auth' );





https://diarioprogramador.com/crear-crud-en-laravel-con-generador-de-cruds/
