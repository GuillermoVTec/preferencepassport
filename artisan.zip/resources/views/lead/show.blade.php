@extends('layouts.app')

@section('template_title')
    {{ $lead->name ?? 'Show Lead' }}
@endsection

@section('content')

            <div class="col-12 col-lg-12 order-2 order-md-3 order-lg-2 mb-4">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Lead</span>
                        </div>
                        <div class="float-right">
                            @role('Distribuidor')
                            <a class="btn btn-primary" href="{{ route('indexDist') }}"> Back</a>
                            @else('Administrador')
                            <a class="btn btn-primary" href="{{ route('indexAdmin') }}"> Back</a>
                            @endrole
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Nombre:</strong>
                            {{ $lead->nombre }}
                        </div>
                        <div class="form-group">
                            <strong>Edad:</strong>
                            {{ $lead->edad }}
                        </div>
                        <div class="form-group">
                            <strong>Estadocivil:</strong>
                            {{ $lead->estadocivil }}
                        </div>
                        <div class="form-group">
                            <strong>Telefono1:</strong>
                            {{ $lead->telefono1 }}
                        </div>
                        <div class="form-group">
                            <strong>Telefono2:</strong>
                            {{ $lead->telefono2 }}
                        </div>
                        <div class="form-group">
                            <strong>Correo:</strong>
                            {{ $lead->correo }}
                        </div>
                        <div class="form-group">
                            <strong>Pais:</strong>
                            {{ $lead->pais }}
                        </div>
                                                <div class="form-group">
                            <strong>Fecha de registro:</strong>
                            {{ $lead->created_at }}
                        </div>
                        @role('Administrador')


                        <div class="form-group">
                            <strong>Usuario:</strong>
                            {{ $lead->user->name }}
                        </div>
                        <div class="form-group">
                            <strong>Estado:</strong>
                            {{ $lead->statuses->nombre }}
                        </div>
                        @endrole

                    </div>
                </div>
            </div>
        </div>
    </section>
     @can('ver nota')
 <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">

                            <span id="card_title">
                                {{ __('Nota') }}
                            </span>


                        </div>
                    </div>
                    @if ($message = Session::get('success'))
                        <div class="alert alert-success">
                            <p>{{ $message }}</p>
                        </div>
                    @endif

                   
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead class="thead">
                                    <tr>
                                        
                                        
                                        <th>Operador</th>
                                        <th>Nota</th>
                                        <th>Fecha de creacion</th>

                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($notas as $nota)
                                    
                                        <tr>
                                           
                                            <td>{{ $nota->user}}</td>
                                            <td>{{ $nota->nota }}</td>
                                           
                                            
                                            <td>{{ $nota->created_at}}</td>

                                            

                                            <td>

                                            </td>
                                        </tr>
                                         
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                   
                </div>
               
            </div>
        </div>
    </div>
     @endcan
@endsection