
  


   
     
          <div class="form-group">
            
            <label class="form-label" for="basic-icon-default-fullname">Nombre Completo</label>
            <div class="input-group input-group-merge">
            <span id="basic-icon-default-fullname2" class="input-group-text"><i class="bx bx-user"></i></span>
            <input id="basic-icon-default-fullname" aria-describedby="basic-icon-default-fullname2" type="text"  class="form-control <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nombre" value="<?php echo e($lead->nombre); ?>"  autocomplete="nombre" autofocus placeholder = 'nombre completo'>

            <?php echo $errors->first('nombre', '<div class="invalid-feedback">El campo Nombre es obligatorio.</div>'); ?>

        </div>
        
        </div>
          <div class="form-group">
            
            <label class="form-label" for="basic-icon-default-fullname">Edad</label>
            <div class="input-group input-group-merge">
            <span id="basic-icon-default-fullname2" class="input-group-text"><i class='bx bx-analyse'></i></span>
            <input id="basic-icon-default-fullname" aria-describedby="basic-icon-default-fullname2" type="text" class="form-control <?php $__errorArgs = ['edad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="edad" value="<?php echo e($lead->edad); ?>"  autocomplete="Edad" autofocus placeholder = 'Edad'>

            <?php echo $errors->first('edad', '<div class="invalid-feedback">El campo Edad es obligatorio.</div>'); ?>

        </div>
        </div>

          <div class="form-group">
            
            <label class="form-label" for="basic-icon-default-fullname">Estado civil</label>
            <div class="input-group input-group-merge">
            <span id="basic-icon-default-fullname2" class="input-group-text"><i class='bx bxs-user-detail' ></i></span>
            <input id="basic-icon-default-fullname" aria-describedby="basic-icon-default-fullname2" type="text" class="form-control <?php $__errorArgs = ['estadocivil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="estadocivil" value="<?php echo e($lead->estadocivil); ?>"  autocomplete="estadocivil"  placeholder = 'estado civil'>

            <?php echo $errors->first('estadocivil', '<div class="invalid-feedback">El campo Estado civil es obligatorio.</div>'); ?>

        </div>
        </div>
        <div class="form-group">
            
            <label class="form-label" for="basic-icon-default-phone2">Teléfono 1</label>
            <div class="input-group input-group-merge">
                <span id="basic-icon-default-phone2" class="input-group-text"><i class="bx bx-phone"></i></span>
                <input id="basic-icon-default-fullname" aria-describedby="basic-icon-default-phone2" type="text" class="form-control <?php $__errorArgs = ['telefono1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="telefono1" value="<?php echo e($lead->telefono1); ?>"  autocomplete="telefono1"  placeholder = 'Telefono obligatorio'>

            <?php echo $errors->first('telefono1', '<div class="invalid-feedback">El campo Estado Telefono  es obligatorio.</div>'); ?>

        </div>
        </div>
        <div class="form-group">
            
            <label class="form-label" for="basic-icon-default-phone">Teléfono 2</label>
            <div class="input-group input-group-merge">
                <span id="basic-icon-default-phone" class="input-group-text"><i class="bx bx-phone"></i></span>
                <input id="basic-icon-default-fullname" aria-describedby="basic-icon-default-phone" type="text" class="form-control <?php $__errorArgs = ['telefono2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="telefono2" value="<?php echo e($lead->telefono2); ?>"  autocomplete="telefono2"  placeholder = 'Telefono obligatorio'>
        <?php echo $errors->first('telefono2', '<div class="invalid-feedback">El campo Estado Telefono  es obligatorio.</div>'); ?>

            
        </div>
        </div>                          
        <div class="form-group">
            
            <label class="form-label" for="basic-icon-default-email">Correo Electronico</label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-envelope"></i></span>
                <input id="basic-icon-default-fullname" aria-describedby="basic-icon-default-email" type="text" class="form-control <?php $__errorArgs = ['correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="correo" value="<?php echo e($lead->correo); ?>"  autocomplete="correo" autofocus placeholder = 'Correo electronico'>
                <?php echo $errors->first('correo', '<div class="invalid-feedback">El campo Correo  es obligatorio.</div>'); ?>

            
        </div>
        </div>
                <div class="form-group">
            
            <label class="form-label" for="basic-icon-default-company">País</label>
            <div class="input-group input-group-merge">
                <span class="input-group-text"><i class="bx bx-globe"></i></span>
                <input id="basic-icon-default-company2" aria-describedby="basic-icon-default-email" type="text" class="form-control <?php $__errorArgs = ['pais'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pais" value="<?php echo e($lead->pais); ?>"  autocomplete="pais" autofocus placeholder = 'Pais'>
                <?php echo $errors->first('correo', '<div class="invalid-feedback">El campo Correo  es obligatorio.</div>'); ?>

            
        </div>
        </div>




        <?php if(Request::url() == 'http://crm.vacationcards.com/leadsCreate'): ?>
  

        <div class="form-group">
            
            <?php echo e(Form::text('user_id', $username, [ 'class' => 'form-control' . ($errors->has('user_id') ? ' is-invalid' : ''),"readonly", "hidden" ,"value" => "username"])); ?>

            <?php echo $errors->first('user_id', '<div class="invalid-feedback">El campo Estado Usuario  es obligatorio.</div>'); ?>

        </div>
        <?php endif; ?>
               <div class="form-group">
            
            <?php echo e(Form::text('created_at2', $date, [ 'class' => 'form-control' . ($errors->has('created_at2') ? ' is-invalid' : ''),"readonly", "hidden" ,"value" => "date"])); ?>

            <?php echo $errors->first('created_at2', '<div class="invalid-feedback">El campo Estado Fecha  es obligatorio.</div>'); ?>

        </div>
        <div class="form-group">
             <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver status')): ?> 
            <?php echo e(Form::label('status')); ?>

            <?php endif; ?>
            
         <select  name='statuses_id' class="form-select" id="exampleFormControlSelect1">
               
                
                <option value="1" selected  >NUEVA</option>

        </select>
        <?php echo $errors->first('statuses_id', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        
         <?php if(Request::url() == 'http://crm.vacationcards.com/leadsCreate'): ?>
         <?php else: ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver nota')): ?>
        
        <div class="form-group">
            <?php echo e(Form::label('Nota')); ?>

            <?php echo e(Form::textArea('nota', $nota->nota, ['class' => 'form-control' . ($errors->has('nota') ? ' is-invalid' : ''),'rows'=>5, "value" => "nota->nota"])); ?>

            <?php echo $errors->first('nota', '<div class="invalid-feedback">El campo Estado Nota es opcional  es obligatorio.</div>'); ?>

        </div>
        <div class="form-group">
            
            <?php echo e(Form::text('leads_id', $nota->leads_id, ['class' => 'form-control' . ($errors->has('leads_id') ? ' is-invalid' : '') ,"readonly", "hidden","value" => "nota->leads_id"])); ?>

            <?php echo $errors->first('leads_id', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            
            <?php echo e(Form::text('user', $username2, ['class' => 'form-control' . ($errors->has('user') ? ' is-invalid' : ''),"readonly", "hidden","value" => "username2"])); ?>

            <?php echo $errors->first('user', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

        <?php endif; ?>
        <?php endif; ?>



  


<?php /**PATH /home/soaonjvfyv03/public_html/crm.vacationcards.com/resources/views/lead/form.blade.php ENDPATH**/ ?>