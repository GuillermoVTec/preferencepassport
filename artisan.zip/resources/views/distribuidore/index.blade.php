@extends('layouts.app')

@section('template_title')
    Distribuidores
@endsection

@section('content')

            <div class="col-12 col-lg-12 order-2 order-md-3 order-lg-2 mb-4">
                <div class="card">
                    <div class="card-header">
                    </div>
                    @if ($message = Session::get('success'))
                        <div class="alert alert-success">
                            <p>{{ $message }}</p>
                        </div>
                    @endif
                <form >
                    <div class="card-body">
                    <div class="row gx-3 gy-2 align-items-center">
                    <div class="col-md-2">
                    <label  class="form-label" for="selectTypeOpt">Desde:</label>
                     
                    <input v class="form-control m"name="fecha1"type="date" >
                    </div>
                    <div class="col-md-2">
                    <label class="form-label" for="selectPlacement">Hasta:</label>
                     
                    <input  class="form-control "name="fecha2"type="date" >
                    </div>
                    <div class="col-md-2">
                    <label class="form-label" for="showToastPlacement">&nbsp;</label>
                    <button id="showToastPlacement" class="btn btn-outline-primary d-block">Buscar</button>
                    </div>
                  
                  
                             @csrf
                        <div class="col-md-2">
                         <label class="form-label" for="selectPlacement">Buscar por matricula id:</label>
                         <input class="form-control d-block" type="search"  name="busqueda"  placeholder="Buscar en mis leads" aria-label="Search" />
                        </div>
                         <div class="col-md-2">
                         <label class="form-label" for="showToastPlacement">&nbsp;</label>
                         <button class="btn btn-outline-primary d-block" type="submit">Buscar</button>
                        </div>
                </form>
             </div>
        </div>
                    <small class="text-muted float-end"></small>
                    </h5>
                    <div class="table-responsive text-nowrap">
                                <table class="table table-hover">
                                <thead >
                                    <tr>
                                        <th>ID</th>
                                        
										<th>Razonsocial</th>
										<th>Representantelegal</th>
										<th>Rfc</th>
										<th>Direccion</th>
										<th>Ciudad</th>
										<th>Pais</th>
										<th>Cp</th>
										<th>Correo</th>
										<th>Telefono</th>
										<th>Date</th>
										<th>Matriculaid</th>
										

                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody class="table-border-bottom-0">
                                    @foreach ($distribuidores as $distribuidore)
                                        <tr>
                                            <td>{{'000'.$distribuidore->matriculaid.$distribuidore->id }}</td>
                                            
											<td>{{ $distribuidore->razonsocial }}</td>
											<td>{{ $distribuidore->representantelegal }}</td>
											<td>{{ $distribuidore->rfc }}</td>
											<td>{{ $distribuidore->direccion }}</td>
											<td>{{ $distribuidore->ciudad }}</td>
											<td>{{ $distribuidore->pais }}</td>
											<td>{{ $distribuidore->cp }}</td>
											<td>{{ $distribuidore->User->email }}</td>
											<td>{{ $distribuidore->telefono }}</td>
											<td>{{ $distribuidore->date }}</td>
											<td>{{ $distribuidore->matriculaid }}</td>
											

                                            <td>



                                                     <div class="dropdown">
                                                     <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                                                    <i class="bx bx-dots-vertical-rounded"></i>
                                                    </button>
                                                    <div class="dropdown-menu">
                                                <form action="{{ route('distribuidores.destroy',$distribuidore->id) }}" method="POST">
                                                    <a class="dropdown-item" href="{{ route('distribuidores.show',$distribuidore->id) }}"><i class="bx bx-show-alt me-1"></i> Show</a>
                                                    
                                                    <a class="dropdown-item" href="{{ route('distribuidores.edit',$distribuidore->id) }}"><i class="bx bx-edit-alt me-1"></i> Edit </a>
                                                    
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit"class="dropdown-item"><i class="bx bx-trash me-1"></i>Delate </button>
                                                </form>
                                                 </div>
                                          </div>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                            {{ $distribuidores->links('pagination::Bootstrap-4') }}
                        </div>
                                        
                </div>
               
            </div>
        </div>
                
                

@endsection
