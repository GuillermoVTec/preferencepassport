
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'CRM Vacation Cards 1.0')); ?></title>

   

    <!-- Icons. Uncomment required icon fonts -->

    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/fonts/boxicons.css')); ?>" />

    <!-- Core CSS -->
   
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/css/core.css')); ?>" class="template-customizer-core-css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/css/theme-default.css')); ?>" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/demo.css')); ?>" />
    

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css')); ?>" />

    <!-- Page CSS -->
    <!-- Page -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/css/pages/page-auth.css')); ?>" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    />
    <!-- Helpers -->
    <script src=" <?php echo e(asset('assets/js/app.js')); ?>"></script>

   
    <script src="<?php echo e(asset('assets/js/config.js')); ?>"></script>

        <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />
   
  
   

    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets/img/favicon/favicon.png')); ?>" />


    <script src="<?php echo e(asset('assets/vendor/js/helpers.js')); ?>"></script>


    
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body>
   <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
       <!-- Menu -->
 <aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
          <div class="app-brand demo">
            <a href="index.html" class="app-brand-link">
               <img src="https://vacationcards.com/nuevo/assets/images/logo/logo.png" width="200" />
            </a>

            <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
              <i class="bx bx-chevron-left bx-sm align-middle"></i>
            </a>
          </div>

          <div class="menu-inner-shadow"></div>

          <ul class="menu-inner py-1">
            <!-- Dashboard -->
            <li class="menu-item">
              <a href="<?php echo e(route('home')); ?>" class="menu-link">
                <i class="menu-icon tf-icons bx bx-detail"></i>
                <div data-i18n="Analytics">Dashboard</div>
              </a>
            </li>
            <li class="menu-item ">
              <a href="" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-detail"></i>
                <div data-i18n="Analytics">leads</div>
              </a>
                 <ul class="menu-sub">
                 <li class="menu-item">
                     <a href="<?php echo e(route('lead.create')); ?>" class="menu-link">
                     <div data-i18n="Without menu">Agregar Lead</div>
                     </a>
                </li>
                </ul>
                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Administrador')): ?>

                <ul class="menu-sub">
                <li class="menu-item">
                    <a href="<?php echo e(route('indexAdmin')); ?>" class="menu-link">
                    <div data-i18n="Without menu">Lista de Lead</div>
                    </a>
                </li>
                </ul>
                <?php else: ?>
    

                <ul class="menu-sub">
                <li class="menu-item">
                    <a href="<?php echo e(route('indexDist')); ?>" class="menu-link">
                    <div data-i18n="Without menu">Lista de Lead</div>
                    </a>
                </li>
                </ul>
                <?php endif; ?>
            </li>
            <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Administrador')): ?>
            <li class="menu-item ">
              <a href="<?php echo e(route('distribuidores.index')); ?>" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-user"></i>
                <div data-i18n="Analytics">Distribuidor</div> 
              </a>
                 <ul class="menu-sub">
                 <li class="menu-item">
                     <a href="<?php echo e(route('register2')); ?>" class="menu-link">
                     <div data-i18n="Without menu">Agregar Distribuidor</div>
                     </a>
                </li>
                </ul>
                <ul class="menu-sub">
                <li class="menu-item">
                    <a href="<?php echo e(route('distribuidores.index')); ?>" class="menu-link">
                    <div data-i18n="Without menu">Lista de Distribuidores</div>
                    </a>
                </li>
                </ul>
                </li>


                        <li class="menu-item">
              <a href="<?php echo e(route('register')); ?>" class="menu-link">
                <i class="menu-icon tf-icons bx bx-cloud-upload"></i>
                <div data-i18n="Analytics">Agregar Nuevo Usuario</div>
              </a>
            </li>

            <?php endif; ?>
            
            
          </ul>
        </aside>
          
        <!-- Layout container -->
        <div class="layout-page">
          <!-- Navbar -->

           <nav
            class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme"
            id="layout-navbar"
          >
            <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
              <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
                <i class="bx bx-menu bx-sm"></i>
              </a>
            </div>

            <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
              <!-- Search -->
              <div class="navbar-nav align-items-center">
                <div class="nav-item d-flex align-items-center">
                 <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="home">Home</a>
                      </li>
                      
                      <li class="nav-item">
                        <a class="nav-link disabled" href="home" tabindex="-1">Dashboard</a>
                      </li>
                    </ul>
                    
                  </div>
                </div>
              </div>
              <!-- /Search -->
                                      <!-- Authentication Links -->
                        <ul class="navbar-nav flex-row align-items-center ms-auto">
                          <li class="nav-item lh-1 me-3">

                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li class="nav-item navbar-dropdown dropdown-user dropdown">
                                 <a class="nav-link dropdown-toggle hide-arrow" href="<?php echo e(route('login')); ?>" data-bs-toggle="dropdown">
                                 <div class="avatar avatar-online">

                                 <img src=" <?php echo e(Auth::user()->getMedia('avatars')->first()->getUrl('thumb')); ?>">
                                 </div><?php echo e(__('Login')); ?>

                                  </a>
                                   
                                </li>
                            <?php endif; ?>

                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>

                            <li class="nav-item dropdown">
                                 <a id="navbarDropdown" class="nav-link dropdown-toggle" href="home" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>

                                 <div class="avatar avatar-online">
                                 
                                 
                                 <img src=" <?php echo e(Auth::user()->getMedia('avatars')->first()->getUrl('thumb')); ?>">
                                 </div><?php echo e(Auth::user()->name); ?>


                                 
                                </a>
                           
                                
                              
                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Cerrar Sesión')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                              </li>
                            
                        <?php endif; ?>
                             </ul>
                             </div>
          </nav>


          <!-- / Navbar -->

          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">


    <!-- / aqui se vera el contenido ajax por wilvive -->
    <main>
            <?php echo $__env->yieldContent('content'); ?>
    </main>

            <footer class="content-footer footer bg-footer-theme">
              <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
                <div class="mb-2 mb-md-0">
                  ©
                  <script>
                    document.write(new Date().getFullYear());
                  </script>
                  VACATION CARDS
                </div>
                <div>
                 <a href="#" target="_blank" class="footer-link me-4"> <i class="menu-icon tf-icons bx bx-support"></i> Soporte</a>
                </div>
              </div>
            </footer>
            <!-- / Footer -->

            <div class="content-backdrop fade"></div>
          </div>
          <!-- Content wrapper -->
        </div>
        <!-- / Layout page -->
      </div>

      <!-- Overlay -->
      <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    <!-- / Layout wrapper -->

    <!-- Core JS -->

  </body>
</html>
    <?php echo \Livewire\Livewire::scripts(); ?>



<!-- / Layout wrapper -->

    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script src="<?php echo e(asset('assets/vendor/libs/jquery/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/libs/popper/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/js/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/vendor/js/menu.js')); ?>"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->
    <script src="<?php echo e(asset('assets/vendor/libs/apex-charts/apexcharts.js')); ?>"></script>

    <!-- Main JS -->
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>

    <!-- Page JS -->
    <script src="<?php echo e(asset('assets/js/dashboards-analytics.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/pages-account-settings-account.js')); ?>"></script>

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
     <!-- Page JS -->
   <?php /**PATH C:\xampp\htdocs\vacationcards\resources\views/layouts/app.blade.php ENDPATH**/ ?>