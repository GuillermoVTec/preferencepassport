<?php return array (
  'leads-component' => 'App\\Http\\Livewire\\LeadsComponent',
  'registro-distribuidor-component' => 'App\\Http\\Livewire\\RegistroDistribuidorComponent',
  'distribuidores-component' => 'App\\Http\\Livewire\\distribuidoresComponent',
);