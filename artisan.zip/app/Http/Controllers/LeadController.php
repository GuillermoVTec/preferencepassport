<?php

namespace App\Http\Controllers;

use App\Models\Lead;
use App\Models\Nota;
use App\Models\statuses;
use App\Models\User;
use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Distribuidore;

/**
 * Class LeadController
 * @package App\Http\Controllers
 */
class LeadController extends Controller
{
        /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response 
     */

         public function index(Request $request){
             $username = auth()->user()->name;
            $userrole = auth()->user()->roles()->first()->name;
            if($userrole=='Administrador'){
                $fecha1= $request->get('fecha1');
                 $fecha2= $request->get('fecha2');
                 
        
                  $nombre= $request->get('busqueda');    
        
                 $leads = lead::nombres($nombre)->fechas($fecha1,$fecha2)->paginate(15);

                 return view('lead.indexAdmin', compact('leads'))
                 ->with('i', (request()->input('page', 1) - 1) * $leads->perPage());

            }else{
                $fecha1= $request->get('fecha1');
                 $fecha2= $request->get('fecha2');

        
                 $nombre= $request->get('busqueda');    
        
                 
                 //$leads = lead::nombres($nombre)->fechas($fecha1,$fecha2)->paginate(15);
                 $leads = lead::with('User')->where('user_id', auth()->user()->id)->nombres($nombre)->fechas($fecha1,$fecha2)->paginate(15);
                  return view('lead.indexDist', compact('leads'))
                  ->with('i', (request()->input('page', 1) - 1) * $leads->perPage());

            }


    }

        public function index2()
    {
      

        return view('livewire.index');
            
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $lead = new lead();
        
        $userrole = auth()->user()->roles()->first()->name;
        $username2 = auth()->user()->name;
        $username = auth()->user()->id;
        
       

     


       return view('lead.create', compact('lead',"username",'username2'));

  




    }

        
        
    

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(Lead::$rules);
//aqui se creara la nota
        $lead = Lead::create($request->all()); 
        
       

        
        


        $username = auth()->user()->name;
        $userrole = auth()->user()->roles()->first()->name;
        if ($userrole=='Administrador') {
             return redirect()->route('indexAdmin')
            ->with('success', 'Lead creado correctamente.');
                   // code...
        }else{
             return redirect()->route('indexDist')
            ->with('success', 'Lead creado correctamente.');
                   // code...
        }
    }



    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $lead = Lead::find($id);

        $notas = lead::find($id)->Nota;
        
     

        return view('lead.show', compact('lead','notas'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        $username2 = auth()->user()->name;
        $username = auth()->user()->id;
        if($username2 == 'Distribuidor'){
            $lead = Lead::find($id);
            $username = auth()->user()->id;
            $username2 = auth()->user()->name;
        }else{
        $lead = Lead::find($id);
        $nota = new Nota();
        $nota->leads_id = $id;
        $username2 = auth()->user()->name;
        $username = auth()->user()->id;
        }

        return view('lead.edit', compact('lead','username','nota','username2'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  Lead $lead
     * @param  Nota $nota
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Lead $lead, Nota $nota)
    {
        request()->validate(Lead::$rules);
     

        $username2 = auth()->user()->name;
        $username = auth()->user()->id;
        if($username2 == 'Distribuidor'){
        $lead->update($request->all());
        
        }else{
        $nota = Nota::create($request->all());
}
        return redirect()->route('indexAdmin')
            ->with('success', 'Lead actualizado successfully');
    }


    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $lead = Lead::find($id)->delete();

        return redirect()->route('lead.index')
            ->with('success', 'Lead deleted successfully');
    }
}
