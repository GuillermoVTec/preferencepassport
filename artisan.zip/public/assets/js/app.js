

require('./bootstrap.js');
require('./config');
require('./dashboards-analytics');
require('./extended-ui-perfect-scrollbar');
require('./form-basic-inputs');
require('./main');
require('./pages-account-settings-account');
require('./ui-modals');
require('./ui-popover');
require('./ui-toasts');
