
  


   
     
        <div class="form-group">
            <?php echo e(Form::label('nombre')); ?>

            <?php echo e(Form::text('nombre', $lead->nombre, ['class' => 'form-control' . ($errors->has('nombre') ? ' is-invalid' : ''), 'placeholder' => 'Nombre'])); ?>

            <?php echo $errors->first('nombre', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('edad')); ?>

            <?php echo e(Form::text('edad', $lead->edad, ['class' => 'form-control' . ($errors->has('edad') ? ' is-invalid' : ''), 'placeholder' => 'Edad'])); ?>

            <?php echo $errors->first('edad', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('estadocivil')); ?>

            <?php echo e(Form::text('estadocivil', $lead->estadocivil, ['class' => 'form-control' . ($errors->has('estadocivil') ? ' is-invalid' : ''), 'placeholder' => 'Estadocivil'])); ?>

            <?php echo $errors->first('estadocivil', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('telefono1')); ?>

            <?php echo e(Form::text('telefono1', $lead->telefono1, ['class' => 'form-control' . ($errors->has('telefono1') ? ' is-invalid' : ''), 'placeholder' => 'Telefono1'])); ?>

            <?php echo $errors->first('telefono1', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('telefono2')); ?>

            <?php echo e(Form::text('telefono2', $lead->telefono2, ['class' => 'form-control' . ($errors->has('telefono2') ? ' is-invalid' : ''), 'placeholder' => 'Telefono2'])); ?>

            <?php echo $errors->first('telefono2', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('correo')); ?>

            <?php echo e(Form::text('correo', $lead->correo, ['class' => 'form-control' . ($errors->has('correo') ? ' is-invalid' : ''), 'placeholder' => 'Correo'])); ?>

            <?php echo $errors->first('correo', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('pais')); ?>

            <?php echo e(Form::text('pais', $lead->pais, ['class' => 'form-control' . ($errors->has('pais') ? ' is-invalid' : ''), 'placeholder' => 'Pais'])); ?>

            <?php echo $errors->first('pais', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

        <?php if(Request::url() === 'http://127.0.0.1:8000/lead/create'): ?>
  

        <div class="form-group">
            
            <?php echo e(Form::text('user_id', $username, [ 'class' => 'form-control' . ($errors->has('user_id') ? ' is-invalid' : ''),"readonly", "hidden" ,"value" => "username"])); ?>

            <?php echo $errors->first('user_id', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <?php endif; ?>
       
        <div class="form-group">
             <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver status')): ?> 
            <?php echo e(Form::label('status')); ?>

            <?php endif; ?>
            
         <select hidden name='statuses_id' class="form-select" id="exampleFormControlSelect1">
               
                
                <option value="1" selected  >NUEVA</option>
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver status')): ?> 
                <option value="5">ACTIVADO</option>
               
                <option value="2">SEGUIMIENTO</option>
                <option value="3">NO CONTESTO</option>
                <option value="4">NO INTERESADO</option>
               <?php endif; ?>
        </select>
        <?php echo $errors->first('statuses_id', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        
         <?php if(Request::url() === 'http://127.0.0.1:8000/lead/create'): ?>
         <?php else: ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver nota')): ?>
        
        <div class="form-group">
            <?php echo e(Form::label('nota')); ?>

            <?php echo e(Form::textArea('nota', $nota->nota, ['class' => 'form-control' . ($errors->has('nota') ? ' is-invalid' : ''),'rows'=>5, "value" => "nota->nota"])); ?>

            <?php echo $errors->first('nota', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('nota')); ?>

            <?php echo e(Form::text('leads_id', $nota->leads_id, ['class' => 'form-control' . ($errors->has('leads_id') ? ' is-invalid' : '') ,"value" => "nota->leads_id"])); ?>

            <?php echo $errors->first('leads_id', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            
            <?php echo e(Form::text('user', $username2, ['class' => 'form-control' . ($errors->has('user') ? ' is-invalid' : ''),"readonly", "hidden","value" => "username2"])); ?>

            <?php echo $errors->first('user', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

        <?php endif; ?>
        <?php endif; ?>



  
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>

<?php /**PATH C:\xampp\htdocs\vacationcards\resources\views/lead/form.blade.php ENDPATH**/ ?>