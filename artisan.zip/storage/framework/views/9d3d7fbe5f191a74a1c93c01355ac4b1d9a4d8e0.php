<?php $__env->startSection('template_title'); ?>
    <?php echo e($lead->name ?? 'Show Lead'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

            <div class="col-12 col-lg-12 order-2 order-md-3 order-lg-2 mb-4">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Lead</span>
                        </div>
                        <div class="float-right">
                            <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Distribuidor')): ?>
                            <a class="btn btn-primary" href="<?php echo e(route('indexDist')); ?>"> Back</a>
                            <?php else: ?>
                            <a class="btn btn-primary" href="<?php echo e(route('indexAdmin')); ?>"> Back</a>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Nombre:</strong>
                            <?php echo e($lead->nombre); ?>

                        </div>
                        <div class="form-group">
                            <strong>Edad:</strong>
                            <?php echo e($lead->edad); ?>

                        </div>
                        <div class="form-group">
                            <strong>Estadocivil:</strong>
                            <?php echo e($lead->estadocivil); ?>

                        </div>
                        <div class="form-group">
                            <strong>Telefono1:</strong>
                            <?php echo e($lead->telefono1); ?>

                        </div>
                        <div class="form-group">
                            <strong>Telefono2:</strong>
                            <?php echo e($lead->telefono2); ?>

                        </div>
                        <div class="form-group">
                            <strong>Correo:</strong>
                            <?php echo e($lead->correo); ?>

                        </div>
                        <div class="form-group">
                            <strong>Pais:</strong>
                            <?php echo e($lead->pais); ?>

                        </div>
                                                <div class="form-group">
                            <strong>Fecha de registro:</strong>
                            <?php echo e($lead->created_at); ?>

                        </div>
                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Administrador')): ?>


                        <div class="form-group">
                            <strong>Usuario:</strong>
                            <?php echo e($lead->user->name); ?>

                        </div>
                        <div class="form-group">
                            <strong>Estado:</strong>
                            <?php echo e($lead->statuses->nombre); ?>

                        </div>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
    </section>
     <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ver nota')): ?>
 <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">

                            <span id="card_title">
                                <?php echo e(__('Nota')); ?>

                            </span>


                        </div>
                    </div>
                    <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success">
                            <p><?php echo e($message); ?></p>
                        </div>
                    <?php endif; ?>

                   
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead class="thead">
                                    <tr>
                                        
                                        
                                        <th>Operador</th>
                                        <th>Nota</th>
                                        <th>Fecha de creacion</th>

                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $notas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                        <tr>
                                           
                                            <td><?php echo e($nota->user); ?></td>
                                            <td><?php echo e($nota->nota); ?></td>
                                           
                                            
                                            <td><?php echo e($nota->created_at); ?></td>

                                            

                                            <td>

                                            </td>
                                        </tr>
                                         
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                   
                </div>
               
            </div>
        </div>
    </div>
     <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vacationcards\resources\views/lead/show.blade.php ENDPATH**/ ?>