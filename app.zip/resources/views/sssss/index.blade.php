  @extends('layouts.app') 
@section('content') 


               <div class="container">  
  
               
               @livewire('distribuidores-component')
               
              
              
                

                
               </div> 

@endsection