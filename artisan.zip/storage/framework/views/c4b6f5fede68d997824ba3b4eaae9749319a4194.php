<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('razonsocial')); ?>

            <?php echo e(Form::text('razonsocial', $distribuidore->razonsocial, ['class' => 'form-control' . ($errors->has('razonsocial') ? ' is-invalid' : ''), 'placeholder' => 'Razonsocial'])); ?>

            <?php echo $errors->first('razonsocial', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('representantelegal')); ?>

            <?php echo e(Form::text('representantelegal', $distribuidore->representantelegal, ['class' => 'form-control' . ($errors->has('representantelegal') ? ' is-invalid' : ''), 'placeholder' => 'Representantelegal'])); ?>

            <?php echo $errors->first('representantelegal', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('rfc')); ?>

            <?php echo e(Form::text('rfc', $distribuidore->rfc, ['class' => 'form-control' . ($errors->has('rfc') ? ' is-invalid' : ''), 'placeholder' => 'Rfc'])); ?>

            <?php echo $errors->first('rfc', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('direccion')); ?>

            <?php echo e(Form::text('direccion', $distribuidore->direccion, ['class' => 'form-control' . ($errors->has('direccion') ? ' is-invalid' : ''), 'placeholder' => 'Direccion'])); ?>

            <?php echo $errors->first('direccion', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('ciudad')); ?>

            <?php echo e(Form::text('ciudad', $distribuidore->ciudad, ['class' => 'form-control' . ($errors->has('ciudad') ? ' is-invalid' : ''), 'placeholder' => 'Ciudad'])); ?>

            <?php echo $errors->first('ciudad', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('pais')); ?>

            <?php echo e(Form::text('pais', $distribuidore->pais, ['class' => 'form-control' . ($errors->has('pais') ? ' is-invalid' : ''), 'placeholder' => 'Pais'])); ?>

            <?php echo $errors->first('pais', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('cp')); ?>

            <?php echo e(Form::text('cp', $distribuidore->cp, ['class' => 'form-control' . ($errors->has('cp') ? ' is-invalid' : ''), 'placeholder' => 'Cp'])); ?>

            <?php echo $errors->first('cp', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('correo')); ?>

            <?php echo e(Form::text('correo', $distribuidore->correo, ['class' => 'form-control' . ($errors->has('correo') ? ' is-invalid' : ''), 'placeholder' => 'Correo'])); ?>

            <?php echo $errors->first('correo', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('telefono')); ?>

            <?php echo e(Form::text('telefono', $distribuidore->telefono, ['class' => 'form-control' . ($errors->has('telefono') ? ' is-invalid' : ''), 'placeholder' => 'Telefono'])); ?>

            <?php echo $errors->first('telefono', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('date')); ?>

            <?php echo e(Form::text('date', $distribuidore->date, ['class' => 'form-control' . ($errors->has('date') ? ' is-invalid' : ''), 'placeholder' => 'Date'])); ?>

            <?php echo $errors->first('date', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('matriculaid')); ?>

            <?php echo e(Form::text('matriculaid', $distribuidore->matriculaid, ['class' => 'form-control' . ($errors->has('matriculaid') ? ' is-invalid' : ''), 'placeholder' => 'Matriculaid'])); ?>

            <?php echo $errors->first('matriculaid', '<div class="invalid-feedback">:message</div>'); ?>

        </div>


    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\vacationcards\resources\views/distribuidore/form.blade.php ENDPATH**/ ?>