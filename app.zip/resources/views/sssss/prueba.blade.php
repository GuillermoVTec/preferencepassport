@extends('layouts.app')

@section('title', 'Probando Livewire!!')

@section('content')

  

    <livewire:registro-distribuidor-component />

@endsection