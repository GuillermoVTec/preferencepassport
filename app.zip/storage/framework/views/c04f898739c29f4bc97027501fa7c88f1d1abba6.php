<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            
            <label class="form-label" for="basic-icon-default-fullname">Razon Social</label>
            <div class="input-group input-group-merge">
            <span id="basic-icon-default-fullname2" class="input-group-text"><i class='bx bxs-buildings'></i></span>
            <input id="basic-icon-default-fullname" aria-describedby="basic-icon-default-fullname2" type="text"  class="form-control <?php $__errorArgs = ['razonsocial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="razonsocial" value="<?php echo e($distribuidore->razonsocial); ?>"  autocomplete="razonsocial" autofocus placeholder = 'razon social'>

            <?php echo $errors->first('razonsocial', '<div class="invalid-feedback">El campo Razon Social es obligatorio.</div>'); ?>

        </div>
        
          <div class="form-group">
            
            <label class="form-label" for="basic-icon-default-fullname">Representante Legal</label>
            <div class="input-group input-group-merge">
            <span id="basic-icon-default-fullname2" class="input-group-text"><i class="bx bx-user"></i></span>
            <input id="basic-icon-default-fullname" aria-describedby="basic-icon-default-fullname2" type="text"  class="form-control <?php $__errorArgs = ['representantelegal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="representantelegal" value="<?php echo e($distribuidore->representantelegal); ?>"  autocomplete="representantelegal" autofocus placeholder = 'Representante legal'>

            <?php echo $errors->first('representantelegal', '<div class="invalid-feedback">El campo Representante Legal es obligatorio.</div>'); ?>

        </div>
        
        <div class="form-group">
            
            <label class="form-label" for="basic-icon-default-fullname">RFC</label>
            <div class="input-group input-group-merge">
            <span id="basic-icon-default-fullname2" class="input-group-text"><i class='bx bxs-spreadsheet'></i></span>
            <input id="basic-icon-default-fullname" aria-describedby="basic-icon-default-fullname2" type="text"  class="form-control <?php $__errorArgs = ['rfc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="rfc" value="<?php echo e($distribuidore->rfc); ?>"  autocomplete="rfc" autofocus placeholder = 'RFC'>

            <?php echo $errors->first('rfc', '<div class="invalid-feedback">El campo RFC es obligatorio.</div>'); ?>

        </div>


        <div class="form-group">
            <?php echo e(Form::label('direccion')); ?>

            <?php echo e(Form::text('direccion', $distribuidore->direccion, ['class' => 'form-control' . ($errors->has('direccion') ? ' is-invalid' : ''), 'placeholder' => 'Direccion'])); ?>

            <?php echo $errors->first('direccion', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('ciudad')); ?>

            <?php echo e(Form::text('ciudad', $distribuidore->ciudad, ['class' => 'form-control' . ($errors->has('ciudad') ? ' is-invalid' : ''), 'placeholder' => 'Ciudad'])); ?>

            <?php echo $errors->first('ciudad', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('pais')); ?>

            <?php echo e(Form::text('pais', $distribuidore->pais, ['class' => 'form-control' . ($errors->has('pais') ? ' is-invalid' : ''), 'placeholder' => 'Pais'])); ?>

            <?php echo $errors->first('pais', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('cp')); ?>

            <?php echo e(Form::text('cp', $distribuidore->cp, ['class' => 'form-control' . ($errors->has('cp') ? ' is-invalid' : ''), 'placeholder' => 'Cp'])); ?>

            <?php echo $errors->first('cp', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('correo')); ?>

            <?php echo e(Form::text('correo', $distribuidore->correo, ['class' => 'form-control' . ($errors->has('correo') ? ' is-invalid' : ''), 'placeholder' => 'Correo'])); ?>

            <?php echo $errors->first('correo', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('telefono')); ?>

            <?php echo e(Form::text('telefono', $distribuidore->telefono, ['class' => 'form-control' . ($errors->has('telefono') ? ' is-invalid' : ''), 'placeholder' => 'Telefono'])); ?>

            <?php echo $errors->first('telefono', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('date')); ?>

            <?php echo e(Form::text('date', $distribuidore->date, ['class' => 'form-control' . ($errors->has('date') ? ' is-invalid' : ''), 'placeholder' => 'Date'])); ?>

            <?php echo $errors->first('date', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('matriculaid')); ?>

            <?php echo e(Form::text('matriculaid', $distribuidore->matriculaid, ['class' => 'form-control' . ($errors->has('matriculaid') ? ' is-invalid' : ''), 'placeholder' => 'Matriculaid'])); ?>

            <?php echo $errors->first('matriculaid', '<div class="invalid-feedback">:message</div>'); ?>

        </div>


    </div>

</div>
             
     
                    </div>
                </div>
               
            </div>
        </div><?php /**PATH /home/soaonjvfyv03/public_html/crm.vacationcards.com/resources/views/distribuidore/form.blade.php ENDPATH**/ ?>